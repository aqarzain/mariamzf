import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const commonConfig = {
  define: {
    underscored: true,
    paranoid: true,
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    deletedAt: 'deleted_at'
  },
  logging: process.env.DB_LOGGING === 'true',
  timezone: process.env.APP_TIMEZONE
};

export default {
  development: {
    ...commonConfig,
    storage: path.join(__dirname, '../', process.env.DB_STORAGE),
    dialect: process.env.DB_DIALECT
  },
  test: {
    ...commonConfig,
    storage: ':memory:',
    dialect: 'sqlite'
  },
  production: {
    ...commonConfig,
    storage: path.join(__dirname, '../', process.env.DB_STORAGE),
    dialect: process.env.DB_DIALECT,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
};
