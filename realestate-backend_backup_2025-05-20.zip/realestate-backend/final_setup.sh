#!/bin/bash

# سكربت الجزء الرابع: الوحدات المساعدة والتهيئة النهائية
# إصدار 4.3 - متوافق مع Termux وأنظمة Linux/macOS
# يشمل: تحميل الملفات، البريد الإلكتروني، المراقبة، التوثيق، وتسجيل الأخطاء

# ------ إعدادات أولية ------
set -e  # إيقاف السكربت عند أول خطأ

# ألوان للواجهة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ------ التحقق من البيئة ------
check_environment() {
    echo -e "${YELLOW}🔍 التحقق من بيئة التنفيذ...${NC}"
    
    if [ ! -f "routes/index.js" ]; then
        echo -e "${RED}❌ يجب تنفيذ الأجزاء السابقة أولاً${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ البيئة جاهزة${NC}"
}

# ------ إنشاء الوحدات المساعدة ------
create_utils() {
    echo -e "${YELLOW}🛠️  جاري إنشاء الوحدات المساعدة...${NC}"
    
    # 1. وحدة تحميل الملفات
    cat > utils/fileUpload.js <<EOL
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const { promisify } = require('util');
const { StatusCodes } = require('http-status-codes');
const logger = require('./logger');

// التهيئة الأساسية
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = process.env.UPLOAD_DIR || './storage/uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, \`\${uuidv4()}\${ext}\`);
    }
});

// التحقق من أنواع الملفات
const fileFilter = (req, file, cb) => {
    const allowedTypes = process.env.ALLOWED_FILE_TYPES?.split(',') || [
        'image/jpeg',
        'image/png',
        'application/pdf'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('نوع الملف غير مدعوم'), false);
    }
};

// تهيئة Multer
const upload = multer({
    storage,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE || 5) * 1024 * 1024
    },
    fileFilter
});

// معالجة أخطاء الرفع
const handleUploadErrors = (err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        logger.error('Upload error', { error: err.message });
        return res.status(StatusCodes.BAD_REQUEST).json({
            success: false,
            message: err.code === 'LIMIT_FILE_SIZE' 
                ? 'حجم الملف يتجاوز الحد المسموح' 
                : 'حدث خطأ أثناء تحميل الملف'
        });
    } else if (err) {
        logger.error('File processing error', { error: err.message });
        return res.status(StatusCodes.BAD_REQUEST).json({
            success: false,
            message: err.message
        });
    }
    next();
};

module.exports = {
    upload,
    handleUploadErrors
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تحميل الملفات${NC}"

    # 2. وحدة البريد الإلكتروني
    cat > utils/email.js <<EOL
const nodemailer = require('nodemailer');
const path = require('path');
const hbs = require('nodemailer-express-handlebars');
const { StatusCodes } = require('http-status-codes');
const logger = require('./logger');

// التهيئة الأساسية
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    },
    tls: {
        rejectUnauthorized: process.env.NODE_ENV === 'production'
    }
});

// تهيئة قوالب البريد
transporter.use('compile', hbs({
    viewEngine: {
        extname: '.hbs',
        layoutsDir: path.join(__dirname, '../views/emails/layouts'),
        defaultLayout: 'main',
        partialsDir: path.join(__dirname, '../views/emails/partials')
    },
    viewPath: path.join(__dirname, '../views/emails'),
    extName: '.hbs'
}));

// دالة الإرسال الرئيسية
const sendEmail = async (options) => {
    if (process.env.NODE_ENV === 'test') {
        logger.info('Email sending skipped in test mode', options);
        return { previewUrl: 'mocked-email-url' };
    }

    try {
        const mailOptions = {
            from: \`"\${process.env.EMAIL_FROM_NAME || 'Real Estate'} <\${process.env.EMAIL_FROM}>\`,
            to: options.to,
            subject: options.subject,
            template: options.template,
            context: options.context,
            attachments: options.attachments
        };

        const info = await transporter.sendMail(mailOptions);
        logger.info('Email sent successfully', { 
            to: options.to,
            subject: options.subject
        });

        return { 
            previewUrl: nodemailer.getTestMessageUrl(info),
            messageId: info.messageId
        };
    } catch (error) {
        logger.error('Email sending failed', { 
            error: error.message,
            stack: error.stack
        });
        throw {
            status: StatusCodes.INTERNAL_SERVER_ERROR,
            message: 'فشل إرسال البريد الإلكتروني',
            originalError: error
        };
    }
};

// نماذج البريد الجاهزة
const emailTemplates = {
    sendActivationEmail: async (user, activationToken) => {
        const activationLink = \`\${process.env.APP_URL}/api/v1/auth/activate/\${activationToken}\`;
        return sendEmail({
            to: user.email,
            subject: 'تفعيل حسابك',
            template: 'activation',
            context: {
                name: user.username,
                activationLink,
                appName: process.env.APP_NAME
            }
        });
    },
    sendPasswordReset: async (user, resetToken) => {
        const resetLink = \`\${process.env.APP_URL}/api/v1/auth/reset-password/\${resetToken}\`;
        return sendEmail({
            to: user.email,
            subject: 'إعادة تعيين كلمة المرور',
            template: 'password-reset',
            context: {
                name: user.username,
                resetLink,
                appName: process.env.APP_NAME
            }
        });
    }
};

module.exports = {
    transporter,
    sendEmail,
    emailTemplates
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة البريد الإلكتروني${NC}"

    # 3. وحدة المراقبة والمقاييس
    cat > utils/monitoring.js <<EOL
const promBundle = require('express-prom-bundle');
const client = require('prom-client');
const logger = require('./logger');

// التهيئة الأساسية
const metricsMiddleware = promBundle({
    includeMethod: true,
    includePath: true,
    includeStatusCode: true,
    includeUp: true,
    customLabels: { 
        project: 'realestate-backend',
        environment: process.env.NODE_ENV || 'development'
    },
    promClient: {
        collectDefaultMetrics: {
            timeout: 5000,
            gcDurationBuckets: [0.001, 0.01, 0.1, 1, 2, 5]
        }
    }
});

// المقاييس المخصصة
const httpRequestDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [0.1, 0.5, 1, 1.5, 2, 3, 5]
});

const dbQueryDuration = new client.Histogram({
    name: 'db_query_duration_seconds',
    help: 'Duration of database queries in seconds',
    labelNames: ['model', 'operation'],
    buckets: [0.01, 0.05, 0.1, 0.5, 1, 2]
});

const errorCounter = new client.Counter({
    name: 'error_count_total',
    help: 'Total number of errors',
    labelNames: ['type', 'endpoint']
});

// دوال المساعدة
const startTimer = () => {
    const start = process.hrtime();
    return () => {
        const diff = process.hrtime(start);
        return diff[0] + diff[1] / 1e9;
    };
};

const monitorRequest = (req, res, next) => {
    const end = httpRequestDuration.startTimer();
    res.on('finish', () => {
        end({
            method: req.method,
            route: req.route?.path || req.path,
            status_code: res.statusCode
        });
        
        if (res.statusCode >= 400) {
            errorCounter.inc({
                type: 'http_error',
                endpoint: req.path
            });
        }
    });
    next();
};

module.exports = {
    metricsMiddleware,
    httpRequestDuration,
    dbQueryDuration,
    errorCounter,
    startTimer,
    monitorRequest
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة المراقبة${NC}"

    # 4. وحدة التوثيق (Swagger)
    cat > utils/swagger.js <<EOL
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const path = require('path');
const { version } = require('../package.json');
const logger = require('./logger');

// تعريفات Swagger الأساسية
const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: process.env.APP_NAME || 'Real Estate API',
            version: version || '1.0.0',
            description: 'واجهة برمجة التطبيقات لنظام إدارة العقارات',
            contact: {
                name: 'الدعم الفني',
                email: 'support@realestate.com'
            },
            license: {
                name: 'MIT'
            }
        },
        servers: [
            {
                url: \`\${process.env.APP_URL}/api/v1\`,
                description: 'الخادم الرئيسي'
            }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT'
                }
            },
            schemas: {
                User: {
                    type: 'object',
                    properties: {
                        user_id: { type: 'string', format: 'uuid' },
                        username: { type: 'string' },
                        email: { type: 'string', format: 'email' },
                        role: { type: 'string', enum: ['admin', 'agent', 'client'] }
                    }
                },
                Property: {
                    type: 'object',
                    properties: {
                        property_id: { type: 'string', format: 'uuid' },
                        title: { type: 'string' },
                        price: { type: 'number', format: 'float' },
                        type: { type: 'string', enum: ['sale', 'rent'] }
                    }
                }
            }
        },
        security: [{
            bearerAuth: []
        }]
    },
    apis: [
        path.join(__dirname, '../routes/*.js'),
        path.join(__dirname, '../controllers/*.js'),
        path.join(__dirname, '../models/*.js')
    ]
};

const specs = swaggerJsdoc(options);

// تهيئة واجهة Swagger
const setupSwagger = (app) => {
    app.use('/api-docs', 
        swaggerUi.serve,
        (req, res, next) => {
            const swaggerOptions = {
                explorer: true,
                swaggerOptions: {
                    validatorUrl: null,
                    docExpansion: 'none'
                },
                customSiteTitle: process.env.APP_NAME || 'Real Estate API Docs'
            };
            
            if (process.env.NODE_ENV === 'production') {
                swaggerOptions.swaggerOptions.persistAuthorization = true;
            }
            
            swaggerUi.setup(specs, swaggerOptions)(req, res, next);
        }
    );

    app.get('/api-docs.json', (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        res.send(specs);
    });

    logger.info('Swagger UI setup completed');
};

module.exports = setupSwagger;
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة التوثيق${NC}"

    # 5. وحدة تسجيل الأخطاء
    cat > utils/logger.js <<EOL
const winston = require('winston');
const { ElasticsearchTransport } = require('winston-elasticsearch');
const path = require('path');
const { createLogger, format, transports } = winston;
const { combine, timestamp, printf, colorize, json } = format;

// تنسيق السجلات للتطوير
const devFormat = printf(({ level, message, timestamp, stack }) => {
    return \`\${timestamp} [\${level}]: \${stack || message}\`;
});

// تنسيق السجلات للإنتاج
const prodFormat = combine(
    timestamp(),
    json()
);

// تهيئة النقل (Transports)
const setupTransports = () => {
    const transportList = [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/error.log'),
            level: 'error',
            maxsize: 5 * 1024 * 1024
        }),
        new transports.File({ 
            filename: path.join(__dirname, '../logs/combined.log'),
            maxsize: 10 * 1024 * 1024
        })
    ];

    if (process.env.NODE_ENV === 'production' && process.env.ELASTICSEARCH_URL) {
        transportList.push(new ElasticsearchTransport({
            level: 'info',
            clientOpts: { node: process.env.ELASTICSEARCH_URL },
            indexPrefix: 'realestate-logs'
        }));
    }

    if (process.env.NODE_ENV !== 'production') {
        transportList.push(new transports.Console({
            format: combine(
                colorize(),
                timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
                devFormat
            )
        }));
    }

    return transportList;
};

// إنشاء الـ logger الرئيسي
const logger = createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: process.env.NODE_ENV === 'production' ? prodFormat : combine(
        timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        devFormat
    ),
    transports: setupTransports(),
    exceptionHandlers: [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/exceptions.log') 
        })
    ],
    rejectionHandlers: [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/rejections.log') 
        })
    ]
});

// دالة لإنشاء سجل للأخطاء مع السياق
const logError = (error, context = {}) => {
    const { message, stack } = error;
    logger.error(message, { 
        stack,
        ...context
    });
};

// دالة لإنشاء سجل للعمليات المهمة
const logActivity = (action, details = {}) => {
    logger.info(action, details);
};

module.exports = {
    logger,
    logError,
    logActivity
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تسجيل الأخطاء${NC}"

    # 6. وحدة تنفيذ الهجرات
    cat > utils/runMigrations.js <<EOL
const { sequelize } = require('../models');
const { Umzug, SequelizeStorage } = require('umzug');
const path = require('path');
const { logger } = require('./logger');

const umzug = new Umzug({
    migrations: {
        glob: path.join(__dirname, '../migrations/*.js'),
        resolve: ({ name, path: migrationPath }) => {
            const migration = require(migrationPath);
            return {
                name,
                up: async () => migration.up({ context: sequelize.getQueryInterface() }),
                down: async () => migration.down({ context: sequelize.getQueryInterface() })
            };
        }
    },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: {
        info: (message) => logger.info(message),
        warn: (message) => logger.warn(message),
        error: (message) => logger.error(message)
    }
});

(async () => {
    try {
        logger.info('Starting migrations...');
        await sequelize.authenticate();
        logger.info('Database connection established');

        const migrations = await umzug.up();
        logger.info(\`\${migrations.length} migrations executed successfully\`);

        process.exit(0);
    } catch (error) {
        logger.error('Migration failed', { 
            error: error.message,
            stack: error.stack
        });
        process.exit(1);
    }
})();
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تنفيذ الهجرات${NC}"

    # 7. وحدة تنفيذ البذور
    cat > utils/runSeeders.js <<EOL
const { sequelize } = require('../models');
const { Umzug, SequelizeStorage } = require('umzug');
const path = require('path');
const { logger } = require('./logger');

const umzug = new Umzug({
    migrations: {
        glob: path.join(__dirname, '../seeders/*.js'),
        resolve: ({ name, path: seederPath }) => {
            const seeder = require(seederPath);
            return {
                name,
                up: async () => seeder.up({ context: sequelize.getQueryInterface() }),
                down: async () => seeder.down({ context: sequelize.getQueryInterface() })
            };
        }
    },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: {
        info: (message) => logger.info(message),
        warn: (message) => logger.warn(message),
        error: (message) => logger.error(message)
    }
});

(async () => {
    try {
        logger.info('Starting seeders...');
        await sequelize.authenticate();
        logger.info('Database connection established');

        const seeders = await umzug.up();
        logger.info(\`\${seeders.length} seeders executed successfully\`);

        process.exit(0);
    } catch (error) {
        logger.error('Seeding failed', { 
            error: error.message,
            stack: error.stack
        });
        process.exit(1);
    }
})();
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تنفيذ البذور${NC}"
}

# ------ إنشاء ملفات التهيئة ------
create_config_files() {
    echo -e "${YELLOW}⚙️  جاري إنشاء ملفات التهيئة...${NC}"
    
    # 1. ملف تهيئة الهجرات
    cat > migrations/.migrations-config.js <<EOL
module.exports = {
    // إعدادات مشتركة للهجرات
    timestampFormat: 'YYYYMMDDHHmmss',
    migrationFileExtension: '.js',
    useTransaction: true,
    logger: console
};
EOL

    # 2. ملف تهيئة البذور
    cat > seeders/.seeders-config.js <<EOL
module.exports = {
    // ترتيب تنفيذ البذور
    executionOrder: [
        'admin-user',
        'property-features',
        'sample-properties'
    ],
    logger: console
};
EOL

    # 3. ملف تهيئة التوثيق
    cat > docs/.swagger-config.js <<EOL
module.exports = {
    openapi: '3.0.0',
    info: {
        version: '1.0.0',
        title: 'Real Estate API'
    },
    servers: [
        { url: 'http://localhost:3000/api/v1' }
    ],
    apis: ['./routes/*.js']
};
EOL

    echo -e "${GREEN}✔ تم إنشاء ملفات التهيئة${NC}"
}

# ------ إنشاء الهيكل الإضافي ------
create_additional_structure() {
    echo -e "${YELLOW}📂 جاري إنشاء الهيكل الإضافي...${NC}"
    
    # 1. مجلدات القوالب
    mkdir -p views/emails/{layouts,partials}
    
    # 2. ملفات البريد الأساسية
    cat > views/emails/layouts/main.hbs <<EOL
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{title}}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; }
        .content { padding: 20px; }
        .footer { margin-top: 20px; font-size: 12px; text-align: center; color: #777; }
        .button { 
            display: inline-block; 
            background-color: #4CAF50; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 5px; 
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{appName}}</h1>
        </div>
        <div class="content">
            {{{body}}}
        </div>
        <div class="footer">
            <p>© {{year}} {{appName}}. جميع الحقوق محفوظة.</p>
        </div>
    </div>
</body>
</html>
EOL

    cat > views/emails/activation.hbs <<EOL
<div>
    <h2>مرحباً {{name}}،</h2>
    <p>شكراً لتسجيلك في نظام {{appName}}. الرجاء الضغط على الزر أدناه لتفعيل حسابك:</p>
    <a href="{{activationLink}}" class="button">تفعيل الحساب</a>
    <p>إذا لم تكن قد قمت بإنشاء هذا الحساب، يمكنك تجاهل هذا البريد.</p>
</div>
EOL

    cat > views/emails/partials/header.hbs <<EOL
<div style="text-align: center; margin-bottom: 20px;">
    <img src="https://example.com/logo.png" alt="{{appName}}" style="max-width: 150px;">
</div>
EOL

    echo -e "${GREEN}✔ تم إنشاء هيكل القوالب${NC}"
}

# ------ تحديث ملف package.json ------
update_package_json() {
    echo -e "${YELLOW}📦 جاري تحديث package.json...${NC}"
    
    # إضافة scripts جديدة
    if [ -f "package.json" ]; then
        npm pkg set scripts.test:watch="NODE_ENV=test jest --watchAll"
        npm pkg set scripts.lint:fix="eslint . --fix"
        npm pkg set scripts.prepare="husky install"
        npm pkg set scripts.migrate:undo="NODE_ENV=development node ./utils/runMigrations.js --down"
        
        # تثبيت التبعيات الإضافية إذا لزم الأمر
        if [[ $(uname -o) != *"Android"* ]]; then
            npm install --save-dev husky lint-staged @commitlint/cli @commitlint/config-conventional
        fi
        
        echo -e "${GREEN}✔ تم تحديث package.json${NC}"
    else
        echo -e "${RED}❌ ملف package.json غير موجود${NC}"
    fi
}

# ------ إنشاء ملفات الإعدادات ------
create_config_files() {
    echo -e "${YELLOW}⚙️  جاري إنشاء ملفات الإعدادات...${NC}"
    
    # 1. ملف إعدادات commitlint
    cat > .commitlintrc.js <<EOL
module.exports = {
    extends: ['@commitlint/config-conventional'],
    rules: {
        'type-enum': [2, 'always', [
            'feat', 'fix', 'docs', 'style', 'refactor', 
            'test', 'chore', 'revert', 'ci', 'perf'
        ]],
        'subject-case': [0]
    }
};
EOL

    # 2. ملف إعدادات lint-staged
    cat > .lintstagedrc.js <<EOL
module.exports = {
    '*.js': ['eslint --fix', 'prettier --write'],
    '*.{json,md}': ['prettier --write']
};
EOL

    # 3. ملف gitignore إضافي
    cat >> .gitignore <<EOL

# ملفات التطوير
.env.local
.vscode/
.idea/

# ملفات الاختبار
coverage/
.nyc_output/

# ملفات النظام
.DS_Store
Thumbs.db
EOL

    echo -e "${GREEN}✔ تم إنشاء ملفات الإعدادات${NC}"
}

# ------ التنفيذ الرئيسي ------
main() {
    echo -e "${GREEN}
    ╔══════════════════════════════╗
    ║   Real Estate Final Setup    ║
    ║   الجزء الرابع - التهيئة   ║
    ╚══════════════════════════════╝
    ${NC}"

    # 1. التحقق من البيئة
    check_environment
    
    # 2. إنشاء الوحدات المساعدة
    create_utils
    
    # 3. إنشاء ملفات التهيئة
    create_config_files
    
    # 4. إنشاء الهيكل الإضافي
    create_additional_structure
    
    # 5. تحديث package.json
    update_package_json
    
    # 6. إنشاء ملفات الإعدادات
    create_config_files
    
    echo -e "${GREEN}
    ✅ تم إكمال التهيئة النهائية بنجاح!
    
    الميزات المضافة:
    - نظام متكامل لإدارة الملفات
    - نظام بريد إلكتروني مع قوالب جاهزة
    - مراقبة الأداء والمقاييس
    - توثيق API تلقائي
    - نظام متقدم لتسجيل الأخطاء
    - إدارة الهجرات والبذور
    - تهيئة Git وضبط الجودة
    
    الأوامر الجديدة المتاحة:
    - npm run migrate        # تنفيذ الهجرات
    - npm run seed           # تنفيذ البذور
    - npm run test:watch     # الاختبار في وضع المراقبة
    - npm run lint:fix       # تصحيح أخطاء ESLint
    
    يمكنك الآن بدء تطوير التطبيق أو نشره للإنتاج.
    ${NC}"
}

# ------ بدء التنفيذ ------
main