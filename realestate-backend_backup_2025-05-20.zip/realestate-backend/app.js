import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { StatusCodes } from 'http-status-codes';
import winston from 'winston';

// تهيئة المسارات
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// تهيئة السجل (Winston)
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ 
      filename: path.join(__dirname, 'logs', 'error.log'), 
      level: 'error' 
    }),
    new winston.transports.File({ 
      filename: path.join(__dirname, 'logs', 'combined.log') 
    })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}

const app = express();

// تحديد معدل الطلبات
const limiter = rateLimit({
  windowMs: process.env.RATE_LIMIT_WINDOW * 60 * 1000, // دقائق
  max: parseInt(process.env.RATE_LIMIT_MAX), // حد الطلبات لكل IP
  message: {
    status: StatusCodes.TOO_MANY_REQUESTS,
    message: 'لقد تجاوزت عدد الطلبات المسموح بها، يرجى المحاولة لاحقاً'
  }
});

// Middleware الأمان
app.use(helmet());
app.use(cors({
  origin: process.env.NODE_ENV === 'development' ? '*' : process.env.APP_URL
}));
app.use(limiter);

// Middleware السجل
app.use(morgan('combined', { 
  stream: fs.createWriteStream(path.join(__dirname, 'logs', 'access.log'), { flags: 'a' }) 
}));

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Middleware لتحليل JSON
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// مسارات API
import authRouter from './routes/auth.route.js';
import userRouter from './routes/user.route.js';
import propertyRouter from './routes/property.route.js';
import contractRouter from './routes/contract.route.js';

app.use('/api/v1/auth', authRouter);
app.use('/api/v1/users', userRouter);
app.use('/api/v1/properties', propertyRouter);
app.use('/api/v1/contracts', contractRouter);

// نقطة فحص الصحة
app.get('/api/v1/health', (req, res) => {
  res.status(StatusCodes.OK).json({ 
    status: 'success',
    message: 'الخادم يعمل بشكل طبيعي',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV
  });
});

// معالجة الأخطاء المركزية
app.use((err, req, res, next) => {
  logger.error(err.stack);

  const statusCode = err.statusCode || StatusCodes.INTERNAL_SERVER_ERROR;
  const message = process.env.NODE_ENV === 'production'
    ? 'حدث خطأ في الخادم'
    : err.message;

  res.status(statusCode).json({
    status: 'error',
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

export default app;
