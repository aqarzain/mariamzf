import app from './app.js';
import { sequelize } from './models/index.js';
import { StatusCodes } from 'http-status-codes';
import dotenv from 'dotenv';

dotenv.config();

const PORT = process.env.APP_PORT || 3000;

async function startServer() {
  try {
    // اختبار اتصال قاعدة البيانات
    await sequelize.authenticate();
    console.log('✅ تم الاتصال بقاعدة البيانات بنجاح');

    // مزامنة النماذج مع قاعدة البيانات
    if (process.env.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      console.log('🔄 تم مزامنة النماذج مع قاعدة البيانات');
    }

    // بدء الخادم
    app.listen(PORT, () => {
      console.log(`🚀 الخادم يعمل على المنفذ ${PORT}`);
      console.log(`📡 البيئة: ${process.env.NODE_ENV}`);
      console.log(`⏰ المنطقة الزمنية: ${process.env.APP_TIMEZONE}`);
      console.log(`🌍 عنوان التطبيق: ${process.env.APP_URL}`);
    });
  } catch (error) {
    console.error('❌ فشل تشغيل الخادم:', error);
    process.exit(1);
  }
}

process.on('unhandledRejection', (err) => {
  console.error('❌ خطأ غير معالج:', err);
  process.exit(1);
});

startServer();
