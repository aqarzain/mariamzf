const nodemailer = require('nodemailer');
const path = require('path');
const hbs = require('nodemailer-express-handlebars');
const { StatusCodes } = require('http-status-codes');
const logger = require('./logger');

// التهيئة الأساسية
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    },
    tls: {
        rejectUnauthorized: process.env.NODE_ENV === 'production'
    }
});

// تهيئة قوالب البريد
transporter.use('compile', hbs({
    viewEngine: {
        extname: '.hbs',
        layoutsDir: path.join(__dirname, '../views/emails/layouts'),
        defaultLayout: 'main',
        partialsDir: path.join(__dirname, '../views/emails/partials')
    },
    viewPath: path.join(__dirname, '../views/emails'),
    extName: '.hbs'
}));

// دالة الإرسال الرئيسية
const sendEmail = async (options) => {
    if (process.env.NODE_ENV === 'test') {
        logger.info('Email sending skipped in test mode', options);
        return { previewUrl: 'mocked-email-url' };
    }

    try {
        const mailOptions = {
            from: `"${process.env.EMAIL_FROM_NAME || 'Real Estate'} <${process.env.EMAIL_FROM}>`,
            to: options.to,
            subject: options.subject,
            template: options.template,
            context: options.context,
            attachments: options.attachments
        };

        const info = await transporter.sendMail(mailOptions);
        logger.info('Email sent successfully', { 
            to: options.to,
            subject: options.subject
        });

        return { 
            previewUrl: nodemailer.getTestMessageUrl(info),
            messageId: info.messageId
        };
    } catch (error) {
        logger.error('Email sending failed', { 
            error: error.message,
            stack: error.stack
        });
        throw {
            status: StatusCodes.INTERNAL_SERVER_ERROR,
            message: 'فشل إرسال البريد الإلكتروني',
            originalError: error
        };
    }
};

// نماذج البريد الجاهزة
const emailTemplates = {
    sendActivationEmail: async (user, activationToken) => {
        const activationLink = `${process.env.APP_URL}/api/v1/auth/activate/${activationToken}`;
        return sendEmail({
            to: user.email,
            subject: 'تفعيل حسابك',
            template: 'activation',
            context: {
                name: user.username,
                activationLink,
                appName: process.env.APP_NAME
            }
        });
    },
    sendPasswordReset: async (user, resetToken) => {
        const resetLink = `${process.env.APP_URL}/api/v1/auth/reset-password/${resetToken}`;
        return sendEmail({
            to: user.email,
            subject: 'إعادة تعيين كلمة المرور',
            template: 'password-reset',
            context: {
                name: user.username,
                resetLink,
                appName: process.env.APP_NAME
            }
        });
    }
};

module.exports = {
    transporter,
    sendEmail,
    emailTemplates
};
