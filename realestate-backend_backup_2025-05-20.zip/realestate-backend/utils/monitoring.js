const promBundle = require('express-prom-bundle');
const client = require('prom-client');
const logger = require('./logger');

// التهيئة الأساسية
const metricsMiddleware = promBundle({
    includeMethod: true,
    includePath: true,
    includeStatusCode: true,
    includeUp: true,
    customLabels: { 
        project: 'realestate-backend',
        environment: process.env.NODE_ENV || 'development'
    },
    promClient: {
        collectDefaultMetrics: {
            timeout: 5000,
            gcDurationBuckets: [0.001, 0.01, 0.1, 1, 2, 5]
        }
    }
});

// المقاييس المخصصة
const httpRequestDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [0.1, 0.5, 1, 1.5, 2, 3, 5]
});

const dbQueryDuration = new client.Histogram({
    name: 'db_query_duration_seconds',
    help: 'Duration of database queries in seconds',
    labelNames: ['model', 'operation'],
    buckets: [0.01, 0.05, 0.1, 0.5, 1, 2]
});

const errorCounter = new client.Counter({
    name: 'error_count_total',
    help: 'Total number of errors',
    labelNames: ['type', 'endpoint']
});

// دوال المساعدة
const startTimer = () => {
    const start = process.hrtime();
    return () => {
        const diff = process.hrtime(start);
        return diff[0] + diff[1] / 1e9;
    };
};

const monitorRequest = (req, res, next) => {
    const end = httpRequestDuration.startTimer();
    res.on('finish', () => {
        end({
            method: req.method,
            route: req.route?.path || req.path,
            status_code: res.statusCode
        });
        
        if (res.statusCode >= 400) {
            errorCounter.inc({
                type: 'http_error',
                endpoint: req.path
            });
        }
    });
    next();
};

module.exports = {
    metricsMiddleware,
    httpRequestDuration,
    dbQueryDuration,
    errorCounter,
    startTimer,
    monitorRequest
};
