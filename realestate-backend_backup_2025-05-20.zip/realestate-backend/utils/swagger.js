const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const path = require('path');
const { version } = require('../package.json');
const logger = require('./logger');

// تعريفات Swagger الأساسية
const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: process.env.APP_NAME || 'Real Estate API',
            version: version || '1.0.0',
            description: 'واجهة برمجة التطبيقات لنظام إدارة العقارات',
            contact: {
                name: 'الدعم الفني',
                email: 'support@realestate.com'
            },
            license: {
                name: 'MIT'
            }
        },
        servers: [
            {
                url: `${process.env.APP_URL}/api/v1`,
                description: 'الخادم الرئيسي'
            }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT'
                }
            },
            schemas: {
                User: {
                    type: 'object',
                    properties: {
                        user_id: { type: 'string', format: 'uuid' },
                        username: { type: 'string' },
                        email: { type: 'string', format: 'email' },
                        role: { type: 'string', enum: ['admin', 'agent', 'client'] }
                    }
                },
                Property: {
                    type: 'object',
                    properties: {
                        property_id: { type: 'string', format: 'uuid' },
                        title: { type: 'string' },
                        price: { type: 'number', format: 'float' },
                        type: { type: 'string', enum: ['sale', 'rent'] }
                    }
                }
            }
        },
        security: [{
            bearerAuth: []
        }]
    },
    apis: [
        path.join(__dirname, '../routes/*.js'),
        path.join(__dirname, '../controllers/*.js'),
        path.join(__dirname, '../models/*.js')
    ]
};

const specs = swaggerJsdoc(options);

// تهيئة واجهة Swagger
const setupSwagger = (app) => {
    app.use('/api-docs', 
        swaggerUi.serve,
        (req, res, next) => {
            const swaggerOptions = {
                explorer: true,
                swaggerOptions: {
                    validatorUrl: null,
                    docExpansion: 'none'
                },
                customSiteTitle: process.env.APP_NAME || 'Real Estate API Docs'
            };
            
            if (process.env.NODE_ENV === 'production') {
                swaggerOptions.swaggerOptions.persistAuthorization = true;
            }
            
            swaggerUi.setup(specs, swaggerOptions)(req, res, next);
        }
    );

    app.get('/api-docs.json', (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        res.send(specs);
    });

    logger.info('Swagger UI setup completed');
};

module.exports = setupSwagger;
