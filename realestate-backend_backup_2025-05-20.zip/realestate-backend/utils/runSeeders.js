const { sequelize } = require('../models');
const { Umzug, SequelizeStorage } = require('umzug');
const path = require('path');
const { logger } = require('./logger');

const umzug = new Umzug({
    migrations: {
        glob: path.join(__dirname, '../seeders/*.js'),
        resolve: ({ name, path: seederPath }) => {
            const seeder = require(seederPath);
            return {
                name,
                up: async () => seeder.up({ context: sequelize.getQueryInterface() }),
                down: async () => seeder.down({ context: sequelize.getQueryInterface() })
            };
        }
    },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: {
        info: (message) => logger.info(message),
        warn: (message) => logger.warn(message),
        error: (message) => logger.error(message)
    }
});

(async () => {
    try {
        logger.info('Starting seeders...');
        await sequelize.authenticate();
        logger.info('Database connection established');

        const seeders = await umzug.up();
        logger.info(`${seeders.length} seeders executed successfully`);

        process.exit(0);
    } catch (error) {
        logger.error('Seeding failed', { 
            error: error.message,
            stack: error.stack
        });
        process.exit(1);
    }
})();
