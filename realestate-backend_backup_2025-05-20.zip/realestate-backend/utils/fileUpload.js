const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const { promisify } = require('util');
const { StatusCodes } = require('http-status-codes');
const logger = require('./logger');

// التهيئة الأساسية
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = process.env.UPLOAD_DIR || './storage/uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, `${uuidv4()}${ext}`);
    }
});

// التحقق من أنواع الملفات
const fileFilter = (req, file, cb) => {
    const allowedTypes = process.env.ALLOWED_FILE_TYPES?.split(',') || [
        'image/jpeg',
        'image/png',
        'application/pdf'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('نوع الملف غير مدعوم'), false);
    }
};

// تهيئة Multer
const upload = multer({
    storage,
    limits: {
        fileSize: parseInt(process.env.MAX_FILE_SIZE || 5) * 1024 * 1024
    },
    fileFilter
});

// معالجة أخطاء الرفع
const handleUploadErrors = (err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        logger.error('Upload error', { error: err.message });
        return res.status(StatusCodes.BAD_REQUEST).json({
            success: false,
            message: err.code === 'LIMIT_FILE_SIZE' 
                ? 'حجم الملف يتجاوز الحد المسموح' 
                : 'حدث خطأ أثناء تحميل الملف'
        });
    } else if (err) {
        logger.error('File processing error', { error: err.message });
        return res.status(StatusCodes.BAD_REQUEST).json({
            success: false,
            message: err.message
        });
    }
    next();
};

module.exports = {
    upload,
    handleUploadErrors
};
