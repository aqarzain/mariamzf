const winston = require('winston');
const { ElasticsearchTransport } = require('winston-elasticsearch');
const path = require('path');
const { createLogger, format, transports } = winston;
const { combine, timestamp, printf, colorize, json } = format;

// تنسيق السجلات للتطوير
const devFormat = printf(({ level, message, timestamp, stack }) => {
    return `${timestamp} [${level}]: ${stack || message}`;
});

// تنسيق السجلات للإنتاج
const prodFormat = combine(
    timestamp(),
    json()
);

// تهيئة النقل (Transports)
const setupTransports = () => {
    const transportList = [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/error.log'),
            level: 'error',
            maxsize: 5 * 1024 * 1024
        }),
        new transports.File({ 
            filename: path.join(__dirname, '../logs/combined.log'),
            maxsize: 10 * 1024 * 1024
        })
    ];

    if (process.env.NODE_ENV === 'production' && process.env.ELASTICSEARCH_URL) {
        transportList.push(new ElasticsearchTransport({
            level: 'info',
            clientOpts: { node: process.env.ELASTICSEARCH_URL },
            indexPrefix: 'realestate-logs'
        }));
    }

    if (process.env.NODE_ENV !== 'production') {
        transportList.push(new transports.Console({
            format: combine(
                colorize(),
                timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
                devFormat
            )
        }));
    }

    return transportList;
};

// إنشاء الـ logger الرئيسي
const logger = createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: process.env.NODE_ENV === 'production' ? prodFormat : combine(
        timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        devFormat
    ),
    transports: setupTransports(),
    exceptionHandlers: [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/exceptions.log') 
        })
    ],
    rejectionHandlers: [
        new transports.File({ 
            filename: path.join(__dirname, '../logs/rejections.log') 
        })
    ]
});

// دالة لإنشاء سجل للأخطاء مع السياق
const logError = (error, context = {}) => {
    const { message, stack } = error;
    logger.error(message, { 
        stack,
        ...context
    });
};

// دالة لإنشاء سجل للعمليات المهمة
const logActivity = (action, details = {}) => {
    logger.info(action, details);
};

module.exports = {
    logger,
    logError,
    logActivity
};
