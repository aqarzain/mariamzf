const { sequelize } = require('../models');
const { Umzug, SequelizeStorage } = require('umzug');
const path = require('path');
const { logger } = require('./logger');

const umzug = new Umzug({
    migrations: {
        glob: path.join(__dirname, '../migrations/*.js'),
        resolve: ({ name, path: migrationPath }) => {
            const migration = require(migrationPath);
            return {
                name,
                up: async () => migration.up({ context: sequelize.getQueryInterface() }),
                down: async () => migration.down({ context: sequelize.getQueryInterface() })
            };
        }
    },
    context: sequelize.getQueryInterface(),
    storage: new SequelizeStorage({ sequelize }),
    logger: {
        info: (message) => logger.info(message),
        warn: (message) => logger.warn(message),
        error: (message) => logger.error(message)
    }
});

(async () => {
    try {
        logger.info('Starting migrations...');
        await sequelize.authenticate();
        logger.info('Database connection established');

        const migrations = await umzug.up();
        logger.info(`${migrations.length} migrations executed successfully`);

        process.exit(0);
    } catch (error) {
        logger.error('Migration failed', { 
            error: error.message,
            stack: error.stack
        });
        process.exit(1);
    }
})();
