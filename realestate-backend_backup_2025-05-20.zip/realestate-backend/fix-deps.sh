#!/data/data/com.termux/files/usr/bin/bash

cd /data/data/com.termux/files/home/realestate-backend

echo "تثبيت الحزم الناقصة..."

npm install http-status-codes

echo "تم التثبيت. يمكنك الآن تشغيل:"
echo "npm run dev"
