const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyReview = sequelize.define('PropertyReview', {
    review_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    rating: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1,
        max: 5
      }
    },
    comment: {
      type: DataTypes.TEXT,
      validate: {
        len: [0, 1000]
      }
    },
    is_approved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['property_id'] },
      { fields: ['user_id'] },
      { fields: ['rating'] },
      { fields: ['is_approved'] }
    ]
  });

  PropertyReview.associate = function(models) {
    PropertyReview.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
    PropertyReview.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
  };

  return PropertyReview;
};
