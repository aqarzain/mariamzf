const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Location = sequelize.define('Location', {
    location_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    city: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 100]
      }
    },
    neighborhood: {
      type: DataTypes.STRING(100),
      validate: {
        len: [0, 100]
      }
    },
    latitude: {
      type: DataTypes.DECIMAL(10, 7),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: -90,
        max: 90
      }
    },
    longitude: {
      type: DataTypes.DECIMAL(10, 7),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: -180,
        max: 180
      }
    },
    zip_code: {
      type: DataTypes.STRING(20),
      validate: {
        len: [0, 20]
      }
    },
    address: {
      type: DataTypes.STRING(255),
      validate: {
        len: [0, 255]
      }
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['city'] },
      { fields: ['neighborhood'] },
      { fields: ['latitude', 'longitude'], using: 'BTREE' }
    ]
  });

  Location.associate = function(models) {
    Location.hasMany(models.Property, { foreignKey: 'location_id', as: 'properties' });
  };

  return Location;
};
