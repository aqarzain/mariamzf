const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Property = sequelize.define('Property', {
    property_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(200),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [5, 200]
      }
    },
    description: {
      type: DataTypes.TEXT,
      validate: {
        len: [0, 5000]
      }
    },
    price: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    type: {
      type: DataTypes.ENUM('sale', 'rent'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('available', 'sold', 'rented', 'pending'),
      defaultValue: 'available'
    },
    bedrooms: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 0
      }
    },
    bathrooms: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 0
      }
    },
    area: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    year_built: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 1800,
        max: new Date().getFullYear()
      }
    },
    is_featured: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    video_url: {
      type: DataTypes.STRING,
      validate: {
        isUrl: true
      }
    },
    floor_plan: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['price'] },
      { fields: ['type', 'status'] },
      { fields: ['location_id'] },
      { fields: ['user_id'] },
      { fields: ['is_featured'] },
      { type: 'FULLTEXT', fields: ['title', 'description'] }
    ]
  });

  Property.associate = function(models) {
    Property.belongsTo(models.User, { foreignKey: 'user_id', as: 'owner' });
    Property.belongsTo(models.Location, { foreignKey: 'location_id', as: 'location' });
    Property.belongsToMany(models.Feature, {
      through: 'PropertyFeatures',
      foreignKey: 'property_id',
      as: 'features'
    });
    Property.hasMany(models.PropertyImage, { foreignKey: 'property_id', as: 'images' });
    Property.hasMany(models.Contract, { foreignKey: 'property_id', as: 'contracts' });
    Property.hasMany(models.PropertyReview, { foreignKey: 'property_id', as: 'reviews' });
  };

  return Property;
};
