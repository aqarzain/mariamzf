const { Sequelize } = require('sequelize');
const config = require('../config/database');
const logger = require('../utils/logger');

// تهيئة Sequelize مع إعدادات خاصة لـ Termux
const sequelize = new Sequelize({
  dialect: config[process.env.NODE_ENV].dialect,
  storage: config[process.env.NODE_ENV].storage,
  logging: msg => logger.debug(msg),
  define: {
    ...config[process.env.NODE_ENV].define,
    // إصلاح مشكلة الجداول في SQLite
    freezeTableName: true,
  }
});

// استيراد النماذج
const User = require('./user.model')(sequelize);
const Property = require('./property.model')(sequelize);
const Location = require('./location.model')(sequelize);
const Feature = require('./feature.model')(sequelize);
const PropertyFeature = require('./propertyFeature.model')(sequelize);
const Contract = require('./contract.model')(sequelize);
const Payment = require('./payment.model')(sequelize);
const Document = require('./document.model')(sequelize);
const PropertyReview = require('./propertyReview.model')(sequelize);
const PropertyImage = require('./propertyImage.model')(sequelize);

// تعريف العلاقات
User.hasMany(Property, { foreignKey: 'user_id', as: 'properties' });
Property.belongsTo(User, { foreignKey: 'user_id', as: 'owner' });

Location.hasMany(Property, { foreignKey: 'location_id', as: 'properties' });
Property.belongsTo(Location, { foreignKey: 'location_id', as: 'location' });

Property.belongsToMany(Feature, {
  through: PropertyFeature,
  foreignKey: 'property_id',
  as: 'features'
});
Feature.belongsToMany(Property, {
  through: PropertyFeature,
  foreignKey: 'feature_id',
  as: 'properties'
});

Property.hasMany(PropertyImage, { foreignKey: 'property_id', as: 'images' });
PropertyImage.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

Property.hasMany(Contract, { foreignKey: 'property_id', as: 'contracts' });
Contract.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

User.hasMany(Contract, { foreignKey: 'client_id', as: 'client_contracts' });
Contract.belongsTo(User, { foreignKey: 'client_id', as: 'client' });

User.hasMany(Contract, { foreignKey: 'agent_id', as: 'agent_contracts' });
Contract.belongsTo(User, { foreignKey: 'agent_id', as: 'agent' });

Contract.hasMany(Payment, { foreignKey: 'contract_id', as: 'payments' });
Payment.belongsTo(Contract, { foreignKey: 'contract_id', as: 'contract' });

User.hasMany(Payment, { foreignKey: 'recorded_by', as: 'recorded_payments' });
Payment.belongsTo(User, { foreignKey: 'recorded_by', as: 'recorder' });

Contract.hasMany(Document, { foreignKey: 'contract_id', as: 'documents' });
Document.belongsTo(Contract, { foreignKey: 'contract_id', as: 'contract' });

User.hasMany(Document, { foreignKey: 'user_id', as: 'documents' });
Document.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Property.hasMany(PropertyReview, { foreignKey: 'property_id', as: 'reviews' });
PropertyReview.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

User.hasMany(PropertyReview, { foreignKey: 'user_id', as: 'reviews' });
PropertyReview.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// مزامنة النماذج مع قاعدة البيانات
const syncModels = async () => {
  try {
    if (process.env.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      logger.info('تم مزامنة النماذج مع قاعدة البيانات');
    } else {
      await sequelize.sync();
    }
  } catch (error) {
    logger.error('فشل مزامنة النماذج:', error);
    process.exit(1);
  }
};

module.exports = {
  sequelize,
  syncModels,
  User,
  Property,
  Location,
  Feature,
  PropertyFeature,
  Contract,
  Payment,
  Document,
  PropertyReview,
  PropertyImage
};
