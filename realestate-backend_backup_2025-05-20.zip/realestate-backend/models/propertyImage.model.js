const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyImage = sequelize.define('PropertyImage', {
    image_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    image_url: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        isUrl: true
      }
    },
    is_primary: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    caption: {
      type: DataTypes.STRING(100),
      validate: {
        len: [0, 100]
      }
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['property_id'] },
      { fields: ['is_primary'] }
    ]
  });

  PropertyImage.associate = function(models) {
    PropertyImage.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
  };

  return PropertyImage;
};
