const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Document = sequelize.define('Document', {
    document_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 100]
      }
    },
    file_url: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        isUrl: true
      }
    },
    document_type: {
      type: DataTypes.ENUM(
        'contract', 
        'id_proof', 
        'property_deed', 
        'payment_receipt',
        'other'
      ),
      allowNull: false
    },
    notes: {
      type: DataTypes.TEXT
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['contract_id'] },
      { fields: ['user_id'] },
      { fields: ['document_type'] }
    ]
  });

  Document.associate = function(models) {
    Document.belongsTo(models.Contract, { foreignKey: 'contract_id', as: 'contract' });
    Document.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
  };

  return Document;
};
