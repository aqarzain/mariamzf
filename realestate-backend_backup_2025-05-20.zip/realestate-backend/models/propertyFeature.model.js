const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyFeature = sequelize.define('PropertyFeature', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    custom_value: {
      type: DataTypes.STRING(50),
      allowNull: true
    }
  }, {
    timestamps: false,
    tableName: 'PropertyFeatures'
  });

  return PropertyFeature;
};
