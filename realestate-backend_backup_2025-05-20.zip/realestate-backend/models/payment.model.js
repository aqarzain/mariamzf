const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Payment = sequelize.define('Payment', {
    payment_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    amount: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    payment_method: {
      type: DataTypes.ENUM(
        'cash', 
        'bank_transfer', 
        'credit_card', 
        'vodafone_cash', 
        'paypal',
        'other'
      ),
      allowNull: false
    },
    transaction_id: {
      type: DataTypes.STRING(100),
      unique: true
    },
    receipt_number: {
      type: DataTypes.STRING(50)
    },
    payment_date: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    },
    notes: {
      type: DataTypes.TEXT
    },
    is_commission_paid: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    status: {
      type: DataTypes.ENUM('pending', 'completed', 'failed', 'refunded'),
      defaultValue: 'pending'
    },
    payment_proof: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['contract_id'] },
      { fields: ['payment_date'] },
      { fields: ['transaction_id'], unique: true },
      { fields: ['status'] }
    ]
  });

  Payment.associate = function(models) {
    Payment.belongsTo(models.Contract, { foreignKey: 'contract_id', as: 'contract' });
    Payment.belongsTo(models.User, { foreignKey: 'recorded_by', as: 'recorder' });
  };

  return Payment;
};
