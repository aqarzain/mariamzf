const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Feature = sequelize.define('Feature', {
    feature_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(50),
      unique: true,
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 50]
      }
    },
    icon: {
      type: DataTypes.STRING(50)
    },
    category: {
      type: DataTypes.ENUM('internal', 'external', 'amenity', 'safety'),
      defaultValue: 'amenity'
    },
    is_filterable: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['name'], unique: true },
      { fields: ['category'] },
      { fields: ['is_filterable'] }
    ]
  });

  Feature.associate = function(models) {
    Feature.belongsToMany(models.Property, {
      through: 'PropertyFeatures',
      foreignKey: 'feature_id',
      as: 'properties'
    });
  };

  return Feature;
};
