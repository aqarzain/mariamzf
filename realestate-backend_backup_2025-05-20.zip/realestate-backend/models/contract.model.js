const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Contract = sequelize.define('Contract', {
    contract_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    start_date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    end_date: {
      type: DataTypes.DATEONLY
    },
    contract_type: {
      type: DataTypes.ENUM('sale', 'rent'),
      allowNull: false
    },
    amount: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    commission_rate: {
      type: DataTypes.DECIMAL(5, 2),
      validate: {
        isDecimal: true,
        min: 0,
        max: 100
      }
    },
    completion_date: {
      type: DataTypes.DATEONLY
    },
    terms: {
      type: DataTypes.TEXT
    },
    status: {
      type: DataTypes.ENUM('active', 'completed', 'terminated', 'pending'),
      defaultValue: 'pending'
    },
    payment_terms: {
      type: DataTypes.TEXT
    },
    notes: {
      type: DataTypes.TEXT
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['client_id'] },
      { fields: ['property_id'] },
      { fields: ['agent_id'] },
      { fields: ['start_date', 'end_date'] },
      { fields: ['status'] }
    ]
  });

  Contract.associate = function(models) {
    Contract.belongsTo(models.User, { foreignKey: 'client_id', as: 'client' });
    Contract.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
    Contract.belongsTo(models.User, { foreignKey: 'agent_id', as: 'agent' });
    Contract.hasMany(models.Payment, { foreignKey: 'contract_id', as: 'payments' });
    Contract.hasMany(models.Document, { foreignKey: 'contract_id', as: 'documents' });
  };

  return Contract;
};
