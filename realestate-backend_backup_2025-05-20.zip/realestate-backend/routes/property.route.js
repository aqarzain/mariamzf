const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/property.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');
const upload = require('../utils/fileUpload').upload;

// مسارات عامة
router.get('/', propertyController.getAllProperties);
router.get('/:id', propertyController.getPropertyById);

// مسارات محمية
router.use(authenticate);

// إنشاء عقار (للوكلاء والمديرين)
router.post(
  '/',
  checkRole(['admin', 'agent']),
  upload.array('images', 10),
  [
    check('title')
      .trim()
      .isLength({ min: 5, max: 200 })
      .withMessage('العنوان يجب أن يكون بين 5 و200 حرف'),
    check('description')
      .optional()
      .isLength({ max: 5000 }),
    check('price')
      .isDecimal()
      .withMessage('يجب أن يكون السعر رقم عشري')
      .toFloat(),
    check('type')
      .isIn(['sale', 'rent'])
      .withMessage('النوع يجب أن يكون بيع أو إيجار'),
    check('bedrooms')
      .optional()
      .isInt({ min: 0 })
      .toInt(),
    check('bathrooms')
      .optional()
      .isInt({ min: 0 })
      .toInt(),
    check('area')
      .optional()
      .isDecimal()
      .toFloat(),
    check('location_id')
      .isUUID()
      .withMessage('معرف الموقع غير صالح'),
    check('features')
      .optional()
      .isArray()
  ],
  propertyController.createProperty
);

// تحديث عقار (للمالك أو المدير)
router.put(
  '/:id',
  [
    check('title')
      .optional()
      .trim()
      .isLength({ min: 5, max: 200 }),
    check('description')
      .optional()
      .isLength({ max: 5000 }),
    check('price')
      .optional()
      .isDecimal()
      .toFloat(),
    check('status')
      .optional()
      .isIn(['available', 'sold', 'rented', 'pending']),
    check('features')
      .optional()
      .isArray()
  ],
  propertyController.updateProperty
);

// حذف عقار (للمالك أو المدير)
router.delete('/:id', propertyController.deleteProperty);

// إدارة صور العقار
router.post('/:id/images', upload.array('images', 10), propertyController.addImages);
router.patch('/:id/images/:imageId/primary', propertyController.setPrimaryImage);
router.delete('/:id/images/:imageId', propertyController.deleteImage);

module.exports = router;
