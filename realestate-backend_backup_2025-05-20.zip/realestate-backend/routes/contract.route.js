const express = require('express');
const router = express.Router();
const contractController = require('../controllers/contract.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');

// مسارات محمية
router.use(authenticate);

// إنشاء عقد (للوكلاء والمديرين)
router.post(
  '/',
  checkRole(['admin', 'agent']),
  [
    check('property_id')
      .isUUID()
      .withMessage('معرف العقار غير صالح'),
    check('client_id')
      .isUUID()
      .withMessage('معرف العميل غير صالح'),
    check('start_date')
      .isDate()
      .withMessage('تاريخ البداية غير صالح'),
    check('end_date')
      .optional()
      .isDate(),
    check('contract_type')
      .isIn(['sale', 'rent'])
      .withMessage('نوع العقد غير صالح'),
    check('amount')
      .isDecimal()
      .withMessage('يجب أن يكون المبلغ رقم عشري')
      .toFloat(),
    check('commission_rate')
      .optional()
      .isDecimal()
      .toFloat()
  ],
  contractController.createContract
);

// الحصول على عقد
router.get('/:id', contractController.getContractById);

// تحديث عقد (للوكيل أو المدير)
router.put(
  '/:id',
  checkRole(['admin', 'agent']),
  [
    check('status')
      .optional()
      .isIn(['active', 'completed', 'terminated', 'pending']),
    check('completion_date')
      .optional()
      .isDate()
  ],
  contractController.updateContract
);

// حذف عقد (للوكيل أو المدير)
router.delete('/:id', checkRole(['admin', 'agent']), contractController.deleteContract);

module.exports = router;
