const express = require('express');
const router = express.Router();
const userRouter = require('./user.route');
const propertyRouter = require('./property.route');
const contractRouter = require('./contract.route');
const { metricsMiddleware } = require('../utils/monitoring');
const setupSwagger = require('../utils/swagger');

// مراقبة الأداء
router.use(metricsMiddleware);

// نقاط النهاية
router.use('/users', userRouter);
router.use('/properties', propertyRouter);
router.use('/contracts', contractRouter);

// نقطة فحص الصحة
router.get('/health', (req, res) => {
  res.json({ 
    status: 'UP',
    timestamp: new Date().toISOString()
  });
});

// توثيق API
setupSwagger(router);

module.exports = router;
