const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');
const upload = require('../utils/fileUpload').upload;

// مسارات عامة
router.post(
  '/register',
  [    check('username')
      .trim()
      .isLength({ min: 3, max: 50 })
      .withMessage('اسم المستخدم يجب أن يكون بين 3 و50 حرفًا')
      .matches(/^[a-zA-Z0-9_]+$/)
      .withMessage('اسم المستخدم يمكن أن يحتوي فقط على أحرف وأرقام وشرطة سفلية'),
    check('email')
      .isEmail()
      .withMessage('البريد الإلكتروني غير صالح')
      .normalizeEmail(),
    check('password')
      .isLength({ min: 8, max: 128 })
      .withMessage('كلمة المرور يجب أن تكون بين 8 و128 حرفًا'),
    check('phone')
      .optional()
      .matches(/^[0-9+]{8,20}$/)
      .withMessage('رقم الهاتف غير صالح'),
    check('role')
      .optional()
      .isIn(['client', 'agent'])
      .withMessage('الدور غير صالح')
  ],
  userController.register
);

router.post(
  '/login',
  [
    check('email')
      .isEmail()
      .withMessage('البريد الإلكتروني غير صالح')
      .normalizeEmail(),
    check('password')
      .notEmpty()
      .withMessage('كلمة المرور مطلوبة')
  ],
  userController.login
);

// مسارات محمية بالمصادقة
router.use(authenticate);

router.get('/me', userController.getMe);

router.put(
  '/:userId',
  [
    check('username')
      .optional()
      .trim()
      .isLength({ min: 3, max: 50 }),
    check('phone')
      .optional()
      .matches(/^[0-9+]{8,20}$/),
    check('profile_image')
      .optional()
      .isURL()
  ],
  userController.updateUser
);

router.delete('/:userId', userController.deleteUser);

// مسارات المدير فقط
router.use(checkRole(['admin']));

router.get('/', userController.getAllUsers);

router.patch('/:userId/status', [
  check('is_active').isBoolean()
], userController.updateUserStatus);

module.exports = router;
