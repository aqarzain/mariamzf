const { User } = require('../models');
const { validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { sendEmail } = require('../utils/email');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// تسجيل مستخدم جديد
exports.register = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn('Validation errors in user registration', { errors: errors.array() });
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { username, email, password, phone, role } = req.body;

        // التحقق من أن الأدوار المسموحة هي 'client' أو 'agent' فقط
        const allowedRoles = ['client', 'agent'];
        if (role && !allowedRoles.includes(role)) {
            logger.warn('Invalid role attempted', { role });
            return res.status(StatusCodes.BAD_REQUEST).json({
                success: false,
                message: 'الدور المسموح به هو client أو agent فقط'
            });
        }

        // التحقق من عدم وجود مستخدم بنفس البريد
        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            logger.warn('Duplicate email registration attempt', { email });
            return res.status(StatusCodes.CONFLICT).json({
                success: false,
                message: 'البريد الإلكتروني مسجل بالفعل'
            });
        }

        const user = await User.create({
            username,
            email,
            password,
            phone,
            role: role || 'client'
        });

        // إنشاء token تفعيل الحساب
        const activationToken = jwt.sign(
            { userId: user.user_id },
            process.env.JWT_ACTIVATION_SECRET,
            { expiresIn: '1d' }
        );

        // إرسال بريد التفعيل
        const activationLink = `${process.env.APP_URL}/api/v1/auth/activate/${activationToken}`;
        await sendEmail({
            to: user.email,
            subject: 'تفعيل حسابك',
            template: 'activation',
            context: {
                username: user.username,
                activationLink
            }
        });

        logger.info('New user registered successfully', { userId: user.user_id });

        res.status(StatusCodes.CREATED).json({
            success: true,
            message: 'تم إنشاء الحساب بنجاح، الرجاء تفعيله عبر الرابط المرسل إلى بريدك',
            data: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        logger.error('Error in user registration', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء الحساب'
        });
    }
};

// تسجيل الدخول
exports.login = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });

        if (!user || !(await user.comparePassword(password))) {
            logger.warn('Failed login attempt', { email });
            return res.status(StatusCodes.UNAUTHORIZED).json({
                success: false,
                message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            });
        }

        if (!user.is_active) {
            logger.warn('Inactive user login attempt', { userId: user.user_id });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'الحساب غير مفعل، الرجاء تفعيله عبر الرابط المرسل إلى بريدك'
            });
        }

        // إنشاء tokens
        const accessToken = jwt.sign(
            { userId: user.user_id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRE }
        );

        const refreshToken = jwt.sign(
            { userId: user.user_id },
            process.env.JWT_REFRESH_SECRET,
            { expiresIn: process.env.JWT_REFRESH_EXPIRE }
        );

        // تحديث آخر تسجيل دخول
        await user.update({ last_login: new Date() });

        logger.info('User logged in successfully', { userId: user.user_id });

        res.json({
            success: true,
            accessToken,
            refreshToken,
            user: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                role: user.role,
                profile_image: user.profile_image
            }
        });
    } catch (error) {
        logger.error('Error in user login', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تسجيل الدخول'
        });
    }
};

// تحديث بيانات المستخدم
exports.updateUser = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { userId } = req.params;
        const user = await User.findByPk(userId);

        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'المستخدم غير موجود'
            });
        }

        // التحقق من الصلاحيات
        if (req.user.user_id !== userId && req.user.role !== 'admin') {
            logger.warn('Unauthorized user update attempt', { 
                requester: req.user.user_id, 
                target: userId 
            });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'غير مسموح بتحديث هذا المستخدم'
            });
        }

        const { username, phone, profile_image } = req.body;
        await user.update({ username, phone, profile_image });

        logger.info('User updated successfully', { userId: user.user_id });

        res.json({
            success: true,
            message: 'تم تحديث بيانات المستخدم بنجاح',
            data: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                phone: user.phone,
                profile_image: user.profile_image
            }
        });
    } catch (error) {
        logger.error('Error updating user', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث بيانات المستخدم'
        });
    }
};

// حذف المستخدم (soft delete)
exports.deleteUser = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await User.findByPk(userId);

        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'المستخدم غير موجود'
            });
        }

        // فقط المدير أو المستخدم نفسه يمكنه الحذف
        if (req.user.user_id !== userId && req.user.role !== 'admin') {
            logger.warn('Unauthorized user deletion attempt', { 
                requester: req.user.user_id, 
                target: userId 
            });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'غير مسموح بحذف هذا المستخدم'
            });
        }

        await user.destroy();
        logger.info('User deleted successfully', { userId: user.user_id });

        res.json({
            success: true,
            message: 'تم حذف المستخدم بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting user', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف المستخدم'
        });
    }
};

// الحصول على بيانات المستخدم الحالي
exports.getMe = async (req, res) => {
    try {
        const user = await User.findByPk(req.user.user_id, {
            attributes: { exclude: ['password'] }
        });

        res.json({
            success: true,
            data: user
        });
    } catch (error) {
        logger.error('Error fetching user profile', { 
            userId: req.user.user_id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب بيانات المستخدم'
        });
    }
};
