const { Property, Location, Feature, PropertyImage, User } = require('../models');
const { validationResult } = require('express-validator');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/fileUpload');
const { Op } = require('sequelize');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// الحصول على جميع العقارات مع التصفية
exports.getAllProperties = async (req, res) => {
    try {
        const { 
            type, 
            status, 
            minPrice, 
            maxPrice, 
            bedrooms, 
            location, 
            features,
            page = 1,
            limit = 10,
            sortBy = 'created_at',
            sortOrder = 'DESC'
        } = req.query;
        
        const where = { deleted_at: null };
        const include = [
            { 
                model: Location, 
                as: 'location',
                attributes: ['city', 'neighborhood', 'latitude', 'longitude']
            },
            { 
                model: Feature, 
                as: 'features',
                attributes: ['name', 'icon', 'category'],
                through: { attributes: [] }
            },
            { 
                model: PropertyImage, 
                as: 'images',
                attributes: ['image_url', 'is_primary'],
                limit: 1
            }
        ];

        // التصفية
        if (type) where.type = type;
        if (status) where.status = status;
        if (minPrice || maxPrice) {
            where.price = {};
            if (minPrice) where.price[Op.gte] = minPrice;
            if (maxPrice) where.price[Op.lte] = maxPrice;
        }
        if (bedrooms) where.bedrooms = bedrooms;
        if (location) include[0].where = { city: location };

        // تصفية حسب الميزات
        if (features) {
            const featureIds = features.split(',');
            include[1].where = { feature_id: featureIds };
        }

        const offset = (page - 1) * limit;

        const properties = await Property.findAndCountAll({
            where,
            include,
            limit: parseInt(limit),
            offset,
            order: [[sortBy, sortOrder]],
            distinct: true
        });

        logger.info('Properties fetched successfully', { 
            count: properties.count,
            filters: req.query 
        });

        res.json({
            success: true,
            data: properties.rows,
            pagination: {
                total: properties.count,
                page: parseInt(page),
                pages: Math.ceil(properties.count / limit),
                limit: parseInt(limit)
            }
        });
    } catch (error) {
        logger.error('Error getting properties', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقارات'
        });
    }
};

// الحصول على عقار بواسطة ID
exports.getPropertyById = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id, {
            include: [
                { 
                    model: Location, 
                    as: 'location',
                    attributes: ['city', 'neighborhood', 'latitude', 'longitude', 'address', 'zip_code']
                },
                { 
                    model: Feature, 
                    as: 'features',
                    attributes: ['name', 'icon', 'category'],
                    through: { attributes: [] }
                },
                { 
                    model: PropertyImage, 
                    as: 'images',
                    attributes: ['image_id', 'image_url', 'is_primary', 'caption']
                },
                { 
                    model: User, 
                    as: 'owner',
                    attributes: ['user_id', 'username', 'email', 'phone', 'profile_image']
                }
            ]
        });

        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        logger.info('Property fetched successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            data: property
        });
    } catch (error) {
        logger.error('Error getting property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقار'
        });
    }
};

// إنشاء عقار جديد
exports.createProperty = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn('Validation errors in property creation', { errors: errors.array() });
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const propertyData = req.body;
        propertyData.user_id = req.user.user_id;

        // إنشاء العقار
        const property = await Property.create(propertyData);
        
        // إضافة الميزات إذا وجدت
        if (req.body.features && req.body.features.length > 0) {
            await property.addFeatures(req.body.features);
        }

        // رفع الصور إذا وجدت
        if (req.files && req.files.length > 0) {
            const uploadPromises = req.files.map((file, index) => 
                uploadToCloudinary(file).then(image => 
                    PropertyImage.create({
                        property_id: property.property_id,
                        image_url: image.url,
                        is_primary: index === 0
                    })
                )
            );
            await Promise.all(uploadPromises);
        }

        logger.info('Property created successfully', { 
            propertyId: property.property_id,
            ownerId: req.user.user_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: property,
            message: 'تم إنشاء العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error creating property', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء العقار'
        });
    }
};

// تحديث عقار موجود
exports.updateProperty = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        // التحقق من ملكية العقار أو صلاحيات المدير
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            logger.warn('Unauthorized property update attempt', { 
                requester: req.user.user_id,
                propertyId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتعديل هذا العقار' 
            });
        }

        await property.update(req.body);
        
        // تحديث الميزات إذا وجدت
        if (req.body.features) {
            await property.setFeatures(req.body.features);
        }

        logger.info('Property updated successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            data: property,
            message: 'تم تحديث العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error updating property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث العقار'
        });
    }
};

// حذف عقار (soft delete)
exports.deleteProperty = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        // التحقق من ملكية العقار أو صلاحيات المدير
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            logger.warn('Unauthorized property deletion attempt', { 
                requester: req.user.user_id,
                propertyId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بحذف هذا العقار' 
            });
        }

        await property.destroy();
        logger.info('Property deleted successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            message: 'تم حذف العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف العقار'
        });
    }
};

// إدارة صور العقار
exports.addImages = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        if (!req.files || req.files.length === 0) {
            return res.status(StatusCodes.BAD_REQUEST).json({ 
                success: false,
                message: 'لم يتم تحميل أي صور' 
            });
        }

        const uploadPromises = req.files.map(file => 
            uploadToCloudinary(file).then(image => 
                PropertyImage.create({
                    property_id: property.property_id,
                    image_url: image.url,
                    is_primary: false
                })
            )
        );

        const images = await Promise.all(uploadPromises);

        logger.info('Property images added successfully', { 
            propertyId: property.property_id,
            count: images.length 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: images,
            message: 'تم إضافة الصور بنجاح'
        });
    } catch (error) {
        logger.error('Error adding property images', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إضافة الصور'
        });
    }
};

// تعيين صورة كأساسية
exports.setPrimaryImage = async (req, res) => {
    try {
        const { id, imageId } = req.params;

        // إلغاء تعيين جميع الصور كغير أساسية
        await PropertyImage.update(
            { is_primary: false },
            { where: { property_id: id } }
        );

        // تعيين الصورة المحددة كأساسية
        const image = await PropertyImage.findOne({
            where: {
                image_id: imageId,
                property_id: id
            }
        });

        if (!image) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الصورة غير موجودة' 
            });
        }

        await image.update({ is_primary: true });

        logger.info('Primary image set successfully', { 
            propertyId: id,
            imageId: imageId 
        });

        res.json({
            success: true,
            message: 'تم تعيين الصورة كأساسية بنجاح'
        });
    } catch (error) {
        logger.error('Error setting primary image', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تعيين الصورة الأساسية'
        });
    }
};

// حذف صورة العقار
exports.deleteImage = async (req, res) => {
    try {
        const { id, imageId } = req.params;

        const image = await PropertyImage.findOne({
            where: {
                image_id: imageId,
                property_id: id
            }
        });

        if (!image) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الصورة غير موجودة' 
            });
        }

        // حذف من التخزين السحابي إذا أمكن
        if (process.env.NODE_ENV === 'production') {
            const publicId = image.image_url.split('/').pop().split('.')[0];
            await deleteFromCloudinary(publicId);
        }

        await image.destroy();

        logger.info('Property image deleted successfully', { 
            propertyId: id,
            imageId: imageId 
        });

        res.json({
            success: true,
            message: 'تم حذف الصورة بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting property image', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف الصورة'
        });
    }
};
