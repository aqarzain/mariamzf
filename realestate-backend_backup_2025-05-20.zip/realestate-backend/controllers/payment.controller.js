const { Payment, Contract } = require('../models');
const { validationResult } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// تسجيل دفعة جديدة
exports.createPayment = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const paymentData = req.body;
        paymentData.recorded_by = req.user.user_id;

        // التحقق من وجود العقد
        const contract = await Contract.findByPk(paymentData.contract_id);
        if (!contract) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'العقد غير موجود'
            });
        }

        // التحقق من الصلاحيات (العميل أو الوكيل أو المدير)
        if (
            req.user.role !== 'admin' &&
            req.user.user_id !== contract.client_id &&
            req.user.user_id !== contract.agent_id
        ) {
            logger.warn('Unauthorized payment creation attempt', { 
                userId: req.user.user_id,
                contractId: paymentData.contract_id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتسجيل دفعة لهذا العقد' 
            });
        }

        const payment = await Payment.create(paymentData);

        logger.info('Payment recorded successfully', { 
            paymentId: payment.payment_id,
            contractId: payment.contract_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: payment,
            message: 'تم تسجيل الدفعة بنجاح'
        });
    } catch (error) {
        logger.error('Error recording payment', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تسجيل الدفعة'
        });
    }
};

// تحديث حالة الدفعة
exports.updatePaymentStatus = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const payment = await Payment.findByPk(req.params.id);
        if (!payment) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الدفعة غير موجودة' 
            });
        }

        // التحقق من الصلاحيات (المدير فقط)
        if (req.user.role !== 'admin') {
            logger.warn('Unauthorized payment update attempt', { 
                userId: req.user.user_id,
                paymentId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتحديث حالة الدفعة' 
            });
        }

        await payment.update({ status: req.body.status });

        logger.info('Payment status updated successfully', { 
            paymentId: payment.payment_id,
            newStatus: req.body.status 
        });

        res.json({
            success: true,
            data: payment,
            message: 'تم تحديث حالة الدفعة بنجاح'
        });
    } catch (error) {
        logger.error('Error updating payment status', { 
            paymentId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث حالة الدفعة'
        });
    }
};
