const { Contract, Property, User, Payment } = require('../models');
const { validationResult } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// إنشاء عقد جديد
exports.createContract = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const contractData = req.body;
        contractData.agent_id = req.user.user_id;

        // التحقق من وجود العقار
        const property = await Property.findByPk(contractData.property_id);
        if (!property) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'العقار غير موجود'
            });
        }

        // التحقق من وجود العميل
        const client = await User.findByPk(contractData.client_id);
        if (!client || client.role !== 'client') {
            return res.status(StatusCodes.BAD_REQUEST).json({
                success: false,
                message: 'العميل غير صالح'
            });
        }

        const contract = await Contract.create(contractData);

        logger.info('Contract created successfully', { 
            contractId: contract.contract_id,
            agentId: req.user.user_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: contract,
            message: 'تم إنشاء العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error creating contract', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء العقد'
        });
    }
};

// الحصول على عقد بواسطة ID
exports.getContractById = async (req, res) => {
    try {
        const contract = await Contract.findByPk(req.params.id, {
            include: [
                {
                    model: Property,
                    as: 'property',
                    include: ['location']
                },
                {
                    model: User,
                    as: 'client',
                    attributes: ['user_id', 'username', 'email', 'phone']
                },
                {
                    model: User,
                    as: 'agent',
                    attributes: ['user_id', 'username', 'email', 'phone']
                },
                {
                    model: Payment,
                    as: 'payments'
                }
            ]
        });

        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (العميل أو الوكيل أو المدير)
        if (
            req.user.role !== 'admin' &&
            req.user.user_id !== contract.client_id &&
            req.user.user_id !== contract.agent_id
        ) {
            logger.warn('Unauthorized contract access attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بالوصول إلى هذا العقد' 
            });
        }

        logger.info('Contract fetched successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            data: contract
        });
    } catch (error) {
        logger.error('Error getting contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقد'
        });
    }
};

// تحديث عقد موجود
exports.updateContract = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const contract = await Contract.findByPk(req.params.id);
        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (الوكيل أو المدير)
        if (req.user.role !== 'admin' && req.user.user_id !== contract.agent_id) {
            logger.warn('Unauthorized contract update attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتعديل هذا العقد' 
            });
        }

        await contract.update(req.body);

        logger.info('Contract updated successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            data: contract,
            message: 'تم تحديث العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error updating contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث العقد'
        });
    }
};

// حذف عقد (soft delete)
exports.deleteContract = async (req, res) => {
    try {
        const contract = await Contract.findByPk(req.params.id);
        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (الوكيل أو المدير)
        if (req.user.role !== 'admin' && req.user.user_id !== contract.agent_id) {
            logger.warn('Unauthorized contract deletion attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بحذف هذا العقد' 
            });
        }

        await contract.destroy();

        logger.info('Contract deleted successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            message: 'تم حذف العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف العقد'
        });
    }
};
