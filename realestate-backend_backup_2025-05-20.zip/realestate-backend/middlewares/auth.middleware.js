const jwt = require('jsonwebtoken');
const { TokenExpiredError } = require('jsonwebtoken');
const { User } = require('../models');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

module.exports = async (req, res, next) => {
  try {
    // 1. التحقق من وجود token في الرأس
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      logger.warn('Attempt to access protected route without token');
      return res.status(StatusCodes.UNAUTHORIZED).json({
        success: false,
        message: 'الرجاء تسجيل الدخول للوصول إلى هذا المورد'
      });
    }

    // 2. التحقق من صحة token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err instanceof TokenExpiredError) {
        logger.warn('Expired token attempt');
        return res.status(StatusCodes.UNAUTHORIZED).json({
          success: false,
          message: 'انتهت صلاحية جلسة العمل، الرجاء تسجيل الدخول مرة أخرى'
        });
      }
      throw err;
    }

    // 3. التحقق من وجود المستخدم
    const currentUser = await User.findByPk(decoded.userId);
    if (!currentUser || currentUser.deleted_at) {
      logger.warn('Invalid token - user not found');
      return res.status(StatusCodes.UNAUTHORIZED).json({
        success: false,
        message: 'المستخدم الذي ينتمي إليه هذا الرمز لم يعد موجودًا'
      });
    }

    // 4. التحقق من أن المستخدم نشط
    if (!currentUser.is_active) {
      logger.warn('Inactive user attempt', { userId: decoded.userId });
      return res.status(StatusCodes.FORBIDDEN).json({
        success: false,
        message: 'حساب المستخدم غير مفعل، الرجاء التواصل مع الدعم الفني'
      });
    }

    // 5. إضافة المستخدم إلى الطلب
    req.user = {
      user_id: currentUser.user_id,
      username: currentUser.username,
      email: currentUser.email,
      role: currentUser.role,
      profile_image: currentUser.profile_image
    };

    logger.info('User authenticated', { userId: currentUser.user_id });
    next();
  } catch (error) {
    logger.error('Authentication error', { 
      error: error.message,
      stack: error.stack 
    });
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'حدث خطأ أثناء المصادقة'
    });
  }
};
