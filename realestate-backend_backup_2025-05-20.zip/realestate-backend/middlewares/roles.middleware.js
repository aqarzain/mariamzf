const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

const checkRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      logger.warn('Unauthorized role attempt', { 
        userRole: req.user?.role, 
        allowedRoles 
      });
      return res.status(StatusCodes.FORBIDDEN).json({ 
        success: false,
        message: 'غير مسموح بالوصول إلى هذا المورد' 
      });
    }
    next();
  };
};

const checkOwnership = (model) => {
  return async (req, res, next) => {
    try {
      const record = await model.findByPk(req.params.id);
      
      if (!record) {
        return res.status(StatusCodes.NOT_FOUND).json({ 
          success: false,
          message: 'السجل غير موجود' 
        });
      }

      // السماح للمديرين دائماً
      if (req.user.role === 'admin') {
        return next();
      }

      // التحقق من ملكية السجل
      if (record.user_id !== req.user.user_id) {
        logger.warn('Unauthorized ownership attempt', { 
          userId: req.user.user_id,
          recordId: req.params.id 
        });
        return res.status(StatusCodes.FORBIDDEN).json({ 
          success: false,
          message: 'غير مسموح بالتعديل على هذا السجل' 
        });
      }

      next();
    } catch (error) {
      logger.error('Ownership check error', { 
        error: error.message,
        stack: error.stack 
      });
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
        success: false,
        message: 'حدث خطأ أثناء التحقق من الملكية' 
      });
    }
  };
};

module.exports = {
  checkRole,
  checkOwnership
};
