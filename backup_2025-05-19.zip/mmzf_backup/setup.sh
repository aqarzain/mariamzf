#!/bin/bash

# سكربت إعداد مشروع Real Estate Backend (الجزء الأول المحدث)
# الإصدار 2.5 - متوافق مع Termux وأنظمة Linux/macOS
# يشمل إصلاحات مشاكل sqlite3 وتهيئة بيئة التطوير

# ------ إعدادات أولية ------
set -e  # إيقاف السكربت عند أول خطأ

# ألوان للواجهة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ------ وظائف مساعدة ------
prepare_environment() {
    echo -e "${YELLOW}🔧 جاري إعداد البيئة...${NC}"
    
    # الكشف عن Termux
    if [[ $(uname -o) == *"Android"* ]]; then
        echo -e "${YELLOW}📱 تم الكشف عن Termux، جاري التهيئة الخاصة...${NC}"
        
        # التحديثات الأساسية
        pkg update -y && pkg upgrade -y
        
        # تثبيت المتطلبات
        pkg install -y python make clang nodejs-lts git
        
        # إعداد node-gyp
        npm install -g node-gyp
        
        # إصلاح مشاكل Python
        if [ ! -f "/usr/bin/python" ]; then
            ln -s $(which python3) /usr/bin/python
        fi
        
        # إعدادات npm لـ Termux
        npm config set python /usr/bin/python
        npm config set user 0
        npm config set unsafe-perm true
        
        echo -e "${GREEN}✅ تم إعداد Termux بنجاح${NC}"
    else
        echo -e "${YELLOW}🖥️  تم الكشف عن نظام عادي (Linux/macOS)${NC}"
        
        # تثبيت المتطلبات لأنظمة Linux
        if command -v apt &> /dev/null; then
            sudo apt update && sudo apt install -y python3 make g++ nodejs npm git
        elif command -v yum &> /dev/null; then
            sudo yum install -y python3 make gcc-c++ nodejs npm git
        fi
    fi
}

check_node_version() {
    echo -e "${YELLOW}🔍 التحقق من إصدار Node.js...${NC}"
    
    if ! command -v node &> /dev/null; then
        echo -e "${RED}❌ يجب تثبيت Node.js الإصدار 16 أو أعلى${NC}"
        exit 1
    fi

    NODE_VERSION=$(node -v | cut -d'.' -f1 | tr -d 'v')
    if [ "$NODE_VERSION" -lt 16 ]; then
        echo -e "${RED}❌ يتطلب Node.js الإصدار 16 أو أعلى (الإصدار الحالي: $(node -v))${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ إصدار Node.js مناسب ($(node -v))${NC}"
}

# ------ التنفيذ الرئيسي ------
main() {
    echo -e "${GREEN}
    ╔══════════════════════════════╗
    ║   Real Estate Backend Setup  ║
    ║   الجزء الأول - الإعدادات   ║
    ╚══════════════════════════════╝
    ${NC}"

    # 1. إعداد البيئة
    prepare_environment
    
    # 2. التحقق من Node.js
    check_node_version
    
    # 3. إنشاء هيكل المشروع
    echo -e "${YELLOW}⚙️  جاري إنشاء هيكل المشروع...${NC}"
    
    PROJECT_NAME="realestate-backend"
    PROJECT_STRUCTURE=(
        "config/"
        "controllers/"
        "middlewares/"
        "models/"
        "routes/"
        "utils/"
        "migrations/"
        "seeders/"
        "tests/"
        "docs/"
        "storage/uploads/"
        "logs/"
        "views/emails/layouts"
        "views/emails/partials"
    )

    mkdir -p $PROJECT_NAME
    cd $PROJECT_NAME
    
    for dir in "${PROJECT_STRUCTURE[@]}"; do
        mkdir -p "$dir"
        echo -e "${GREEN}✔ تم إنشاء مجلد $dir${NC}"
    done

    # 4. تهيئة package.json مع إصلاح sqlite3
    echo -e "${YELLOW}📦 جاري تهيئة package.json...${NC}"
    
    cat > package.json <<EOL
{
  "name": "$PROJECT_NAME",
  "version": "1.0.0",
  "description": "Real Estate Management System Backend",
  "main": "server.js",
  "type": "module",
  "scripts": {
    "start": "NODE_ENV=production node server.js",
    "dev": "NODE_ENV=development nodemon server.js",
    "migrate": "NODE_ENV=development node ./utils/runMigrations.js",
    "seed": "NODE_ENV=development node ./utils/runSeeders.js",
    "test": "NODE_ENV=test jest --coverage",
    "lint": "eslint .",
    "format": "prettier --write .",
    "docs": "apidoc -i routes/ -o docs/"
  },
  "keywords": [
    "realestate",
    "backend",
    "nodejs",
    "express",
    "sequelize"
  ],
  "author": "Your Name <your.email@example.com>",
  "license": "MIT",
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "express-async-errors": "^3.1.1",
    "express-rate-limit": "^6.7.0",
    "express-validator": "^7.0.1",
    "helmet": "^7.1.0",
    "http-status-codes": "^2.2.0",
    "jsonwebtoken": "^9.0.2",
    "moment": "^2.29.4",
    "morgan": "^1.10.0",
    "sequelize": "^6.35.2",
    "$( [[ $(uname -o) == *"Android"* ]] && echo "better-sqlite3" || echo "sqlite3" )": "^$( [[ $(uname -o) == *"Android"* ]] && echo "8.6.0" || echo "5.1.6" )",
    "uuid": "^9.0.1",
    "winston": "^3.11.0"
  },
  "devDependencies": {
    "eslint": "^8.47.0",
    "eslint-config-airbnb-base": "^15.0.0",
    "eslint-plugin-import": "^2.28.1",
    "jest": "^29.6.4",
    "nodemon": "^3.0.2",
    "prettier": "^3.0.2",
    "supertest": "^6.3.3"
  }
}
EOL

    # 5. تثبيت التبعيات
    echo -e "${YELLOW}📦 جاري تثبيت dependencies...${NC}"
    npm install
    
    echo -e "${YELLOW}📦 جاري تثبيت devDependencies...${NC}"
    npm install --only=dev

    # 6. إنشاء ملفات التهيئة الأساسية
    create_config_files

    echo -e "${GREEN}
    ✅ تم إعداد المشروع بنجاح!
    → استخدم الأوامر التالية:
    cd $PROJECT_NAME
    npm run dev
    ${NC}"
}

create_config_files() {
    # إنشاء ملف .env
    cat > .env <<EOL
# إعدادات التطبيق
NODE_ENV=development
APP_NAME=$PROJECT_NAME
APP_PORT=3000
APP_URL=http://localhost:3000
APP_TIMEZONE=Africa/Cairo

# إعدادات قاعدة البيانات
DB_STORAGE=./storage/database.sqlite
DB_DIALECT=sqlite
DB_LOGGING=false

# إعدادات الأمان
JWT_SECRET=your_strong_jwt_secret_here
JWT_EXPIRE=7d
CRYPTO_SECRET=your_crypto_secret_here
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX=100

# إعدادات التخزين
UPLOAD_DIR=./storage/uploads
MAX_FILE_SIZE=5
ALLOWED_FILE_TYPES=image/jpeg,image/png

# إعدادات البريد الإلكتروني (اختياري)
SMTP_HOST=your_smtp_host
SMTP_PORT=587
SMTP_USER=your_smtp_user
SMTP_PASS=your_smtp_pass
EMAIL_FROM=no-reply@realestate.com
EOL

    # إنشاء ملف gitignore
    cat > .gitignore <<EOL
# التبعيات
node_modules/

# الملفات البيئية
.env
.env*.local

# قاعدة البيانات
*.sqlite
*.sqlite-journal

# التخزين
/storage/*
!/storage/uploads
!/storage/uploads/.gitkeep

# السجلات
/logs/*

# نظام التشغيل
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/

# الاختبارات والتغطية
coverage/
.nyc_output/

# المستندات
docs/
EOL

    # إنشاء ملف تكوين قاعدة البيانات
    cat > config/database.js <<EOL
const path = require('path');

module.exports = {
  development: {
    dialect: 'sqlite',
    storage: path.join(__dirname, '../storage/database.sqlite'),
    logging: console.log,
    define: {
      underscored: true,
      paranoid: true,
      timestamps: true,
      createdAt: 'created_at',
      updatedAt: 'updated_at',
      deletedAt: 'deleted_at'
    }
  },
  test: {
    dialect: 'sqlite',
    storage: ':memory:',
    logging: false
  },
  production: {
    dialect: 'sqlite',
    storage: path.join(__dirname, '../storage/database.sqlite'),
    logging: false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
};
EOL
}

# ------ بدء التنفيذ ------
main