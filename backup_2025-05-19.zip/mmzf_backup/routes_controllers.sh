#!/bin/bash

# سكربت الجزء الثالث: وحدات التحكم والمسارات المحدثة
# إصدار 3.2 - متوافق مع Termux وأنظمة Linux/macOS
# يشمل تحسينات الأمان، التحقق من الصحة، وإدارة الأخطاء

# ------ إعدادات أولية ------
set -e  # إيقاف السكربت عند أول خطأ

# ألوان للواجهة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ------ التحقق من البيئة ------
check_environment() {
    echo -e "${YELLOW}🔍 التحقق من بيئة التنفيذ...${NC}"
    
    if [ ! -f "models/index.js" ]; then
        echo -e "${RED}❌ يجب تنفيذ الجزء الثاني أولاً (models_setup.sh)${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ البيئة جاهزة${NC}"
}

# ------ إنشاء وحدات التحكم ------
create_controllers() {
    echo -e "${YELLOW}⚙️  جاري إنشاء وحدات التحكم...${NC}"
    
    # 1. وحدة تحكم المستخدمين
    cat > controllers/user.controller.js <<EOL
const { User } = require('../models');
const { validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { sendEmail } = require('../utils/email');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// تسجيل مستخدم جديد
exports.register = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn('Validation errors in user registration', { errors: errors.array() });
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { username, email, password, phone, role } = req.body;

        // التحقق من أن الأدوار المسموحة هي 'client' أو 'agent' فقط
        const allowedRoles = ['client', 'agent'];
        if (role && !allowedRoles.includes(role)) {
            logger.warn('Invalid role attempted', { role });
            return res.status(StatusCodes.BAD_REQUEST).json({
                success: false,
                message: 'الدور المسموح به هو client أو agent فقط'
            });
        }

        // التحقق من عدم وجود مستخدم بنفس البريد
        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            logger.warn('Duplicate email registration attempt', { email });
            return res.status(StatusCodes.CONFLICT).json({
                success: false,
                message: 'البريد الإلكتروني مسجل بالفعل'
            });
        }

        const user = await User.create({
            username,
            email,
            password,
            phone,
            role: role || 'client'
        });

        // إنشاء token تفعيل الحساب
        const activationToken = jwt.sign(
            { userId: user.user_id },
            process.env.JWT_ACTIVATION_SECRET,
            { expiresIn: '1d' }
        );

        // إرسال بريد التفعيل
        const activationLink = \`\${process.env.APP_URL}/api/v1/auth/activate/\${activationToken}\`;
        await sendEmail({
            to: user.email,
            subject: 'تفعيل حسابك',
            template: 'activation',
            context: {
                username: user.username,
                activationLink
            }
        });

        logger.info('New user registered successfully', { userId: user.user_id });

        res.status(StatusCodes.CREATED).json({
            success: true,
            message: 'تم إنشاء الحساب بنجاح، الرجاء تفعيله عبر الرابط المرسل إلى بريدك',
            data: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        logger.error('Error in user registration', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء الحساب'
        });
    }
};

// تسجيل الدخول
exports.login = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });

        if (!user || !(await user.comparePassword(password))) {
            logger.warn('Failed login attempt', { email });
            return res.status(StatusCodes.UNAUTHORIZED).json({
                success: false,
                message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            });
        }

        if (!user.is_active) {
            logger.warn('Inactive user login attempt', { userId: user.user_id });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'الحساب غير مفعل، الرجاء تفعيله عبر الرابط المرسل إلى بريدك'
            });
        }

        // إنشاء tokens
        const accessToken = jwt.sign(
            { userId: user.user_id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRE }
        );

        const refreshToken = jwt.sign(
            { userId: user.user_id },
            process.env.JWT_REFRESH_SECRET,
            { expiresIn: process.env.JWT_REFRESH_EXPIRE }
        );

        // تحديث آخر تسجيل دخول
        await user.update({ last_login: new Date() });

        logger.info('User logged in successfully', { userId: user.user_id });

        res.json({
            success: true,
            accessToken,
            refreshToken,
            user: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                role: user.role,
                profile_image: user.profile_image
            }
        });
    } catch (error) {
        logger.error('Error in user login', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تسجيل الدخول'
        });
    }
};

// تحديث بيانات المستخدم
exports.updateUser = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const { userId } = req.params;
        const user = await User.findByPk(userId);

        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'المستخدم غير موجود'
            });
        }

        // التحقق من الصلاحيات
        if (req.user.user_id !== userId && req.user.role !== 'admin') {
            logger.warn('Unauthorized user update attempt', { 
                requester: req.user.user_id, 
                target: userId 
            });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'غير مسموح بتحديث هذا المستخدم'
            });
        }

        const { username, phone, profile_image } = req.body;
        await user.update({ username, phone, profile_image });

        logger.info('User updated successfully', { userId: user.user_id });

        res.json({
            success: true,
            message: 'تم تحديث بيانات المستخدم بنجاح',
            data: {
                user_id: user.user_id,
                username: user.username,
                email: user.email,
                phone: user.phone,
                profile_image: user.profile_image
            }
        });
    } catch (error) {
        logger.error('Error updating user', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث بيانات المستخدم'
        });
    }
};

// حذف المستخدم (soft delete)
exports.deleteUser = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await User.findByPk(userId);

        if (!user) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'المستخدم غير موجود'
            });
        }

        // فقط المدير أو المستخدم نفسه يمكنه الحذف
        if (req.user.user_id !== userId && req.user.role !== 'admin') {
            logger.warn('Unauthorized user deletion attempt', { 
                requester: req.user.user_id, 
                target: userId 
            });
            return res.status(StatusCodes.FORBIDDEN).json({
                success: false,
                message: 'غير مسموح بحذف هذا المستخدم'
            });
        }

        await user.destroy();
        logger.info('User deleted successfully', { userId: user.user_id });

        res.json({
            success: true,
            message: 'تم حذف المستخدم بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting user', { error: error.message, stack: error.stack });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف المستخدم'
        });
    }
};

// الحصول على بيانات المستخدم الحالي
exports.getMe = async (req, res) => {
    try {
        const user = await User.findByPk(req.user.user_id, {
            attributes: { exclude: ['password'] }
        });

        res.json({
            success: true,
            data: user
        });
    } catch (error) {
        logger.error('Error fetching user profile', { 
            userId: req.user.user_id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب بيانات المستخدم'
        });
    }
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تحكم المستخدمين${NC}"

    # 2. وحدة تحكم العقارات
    cat > controllers/property.controller.js <<EOL
const { Property, Location, Feature, PropertyImage, User } = require('../models');
const { validationResult } = require('express-validator');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/fileUpload');
const { Op } = require('sequelize');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// الحصول على جميع العقارات مع التصفية
exports.getAllProperties = async (req, res) => {
    try {
        const { 
            type, 
            status, 
            minPrice, 
            maxPrice, 
            bedrooms, 
            location, 
            features,
            page = 1,
            limit = 10,
            sortBy = 'created_at',
            sortOrder = 'DESC'
        } = req.query;
        
        const where = { deleted_at: null };
        const include = [
            { 
                model: Location, 
                as: 'location',
                attributes: ['city', 'neighborhood', 'latitude', 'longitude']
            },
            { 
                model: Feature, 
                as: 'features',
                attributes: ['name', 'icon', 'category'],
                through: { attributes: [] }
            },
            { 
                model: PropertyImage, 
                as: 'images',
                attributes: ['image_url', 'is_primary'],
                limit: 1
            }
        ];

        // التصفية
        if (type) where.type = type;
        if (status) where.status = status;
        if (minPrice || maxPrice) {
            where.price = {};
            if (minPrice) where.price[Op.gte] = minPrice;
            if (maxPrice) where.price[Op.lte] = maxPrice;
        }
        if (bedrooms) where.bedrooms = bedrooms;
        if (location) include[0].where = { city: location };

        // تصفية حسب الميزات
        if (features) {
            const featureIds = features.split(',');
            include[1].where = { feature_id: featureIds };
        }

        const offset = (page - 1) * limit;

        const properties = await Property.findAndCountAll({
            where,
            include,
            limit: parseInt(limit),
            offset,
            order: [[sortBy, sortOrder]],
            distinct: true
        });

        logger.info('Properties fetched successfully', { 
            count: properties.count,
            filters: req.query 
        });

        res.json({
            success: true,
            data: properties.rows,
            pagination: {
                total: properties.count,
                page: parseInt(page),
                pages: Math.ceil(properties.count / limit),
                limit: parseInt(limit)
            }
        });
    } catch (error) {
        logger.error('Error getting properties', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقارات'
        });
    }
};

// الحصول على عقار بواسطة ID
exports.getPropertyById = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id, {
            include: [
                { 
                    model: Location, 
                    as: 'location',
                    attributes: ['city', 'neighborhood', 'latitude', 'longitude', 'address', 'zip_code']
                },
                { 
                    model: Feature, 
                    as: 'features',
                    attributes: ['name', 'icon', 'category'],
                    through: { attributes: [] }
                },
                { 
                    model: PropertyImage, 
                    as: 'images',
                    attributes: ['image_id', 'image_url', 'is_primary', 'caption']
                },
                { 
                    model: User, 
                    as: 'owner',
                    attributes: ['user_id', 'username', 'email', 'phone', 'profile_image']
                }
            ]
        });

        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        logger.info('Property fetched successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            data: property
        });
    } catch (error) {
        logger.error('Error getting property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقار'
        });
    }
};

// إنشاء عقار جديد
exports.createProperty = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn('Validation errors in property creation', { errors: errors.array() });
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const propertyData = req.body;
        propertyData.user_id = req.user.user_id;

        // إنشاء العقار
        const property = await Property.create(propertyData);
        
        // إضافة الميزات إذا وجدت
        if (req.body.features && req.body.features.length > 0) {
            await property.addFeatures(req.body.features);
        }

        // رفع الصور إذا وجدت
        if (req.files && req.files.length > 0) {
            const uploadPromises = req.files.map((file, index) => 
                uploadToCloudinary(file).then(image => 
                    PropertyImage.create({
                        property_id: property.property_id,
                        image_url: image.url,
                        is_primary: index === 0
                    })
                )
            );
            await Promise.all(uploadPromises);
        }

        logger.info('Property created successfully', { 
            propertyId: property.property_id,
            ownerId: req.user.user_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: property,
            message: 'تم إنشاء العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error creating property', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء العقار'
        });
    }
};

// تحديث عقار موجود
exports.updateProperty = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        // التحقق من ملكية العقار أو صلاحيات المدير
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            logger.warn('Unauthorized property update attempt', { 
                requester: req.user.user_id,
                propertyId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتعديل هذا العقار' 
            });
        }

        await property.update(req.body);
        
        // تحديث الميزات إذا وجدت
        if (req.body.features) {
            await property.setFeatures(req.body.features);
        }

        logger.info('Property updated successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            data: property,
            message: 'تم تحديث العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error updating property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث العقار'
        });
    }
};

// حذف عقار (soft delete)
exports.deleteProperty = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        // التحقق من ملكية العقار أو صلاحيات المدير
        if (property.user_id !== req.user.user_id && req.user.role !== 'admin') {
            logger.warn('Unauthorized property deletion attempt', { 
                requester: req.user.user_id,
                propertyId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بحذف هذا العقار' 
            });
        }

        await property.destroy();
        logger.info('Property deleted successfully', { propertyId: property.property_id });

        res.json({
            success: true,
            message: 'تم حذف العقار بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting property', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف العقار'
        });
    }
};

// إدارة صور العقار
exports.addImages = async (req, res) => {
    try {
        const property = await Property.findByPk(req.params.id);
        if (!property || property.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقار غير موجود' 
            });
        }

        if (!req.files || req.files.length === 0) {
            return res.status(StatusCodes.BAD_REQUEST).json({ 
                success: false,
                message: 'لم يتم تحميل أي صور' 
            });
        }

        const uploadPromises = req.files.map(file => 
            uploadToCloudinary(file).then(image => 
                PropertyImage.create({
                    property_id: property.property_id,
                    image_url: image.url,
                    is_primary: false
                })
            )
        );

        const images = await Promise.all(uploadPromises);

        logger.info('Property images added successfully', { 
            propertyId: property.property_id,
            count: images.length 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: images,
            message: 'تم إضافة الصور بنجاح'
        });
    } catch (error) {
        logger.error('Error adding property images', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إضافة الصور'
        });
    }
};

// تعيين صورة كأساسية
exports.setPrimaryImage = async (req, res) => {
    try {
        const { id, imageId } = req.params;

        // إلغاء تعيين جميع الصور كغير أساسية
        await PropertyImage.update(
            { is_primary: false },
            { where: { property_id: id } }
        );

        // تعيين الصورة المحددة كأساسية
        const image = await PropertyImage.findOne({
            where: {
                image_id: imageId,
                property_id: id
            }
        });

        if (!image) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الصورة غير موجودة' 
            });
        }

        await image.update({ is_primary: true });

        logger.info('Primary image set successfully', { 
            propertyId: id,
            imageId: imageId 
        });

        res.json({
            success: true,
            message: 'تم تعيين الصورة كأساسية بنجاح'
        });
    } catch (error) {
        logger.error('Error setting primary image', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تعيين الصورة الأساسية'
        });
    }
};

// حذف صورة العقار
exports.deleteImage = async (req, res) => {
    try {
        const { id, imageId } = req.params;

        const image = await PropertyImage.findOne({
            where: {
                image_id: imageId,
                property_id: id
            }
        });

        if (!image) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الصورة غير موجودة' 
            });
        }

        // حذف من التخزين السحابي إذا أمكن
        if (process.env.NODE_ENV === 'production') {
            const publicId = image.image_url.split('/').pop().split('.')[0];
            await deleteFromCloudinary(publicId);
        }

        await image.destroy();

        logger.info('Property image deleted successfully', { 
            propertyId: id,
            imageId: imageId 
        });

        res.json({
            success: true,
            message: 'تم حذف الصورة بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting property image', { 
            propertyId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف الصورة'
        });
    }
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تحكم العقارات${NC}"

    # 3. إنشاء وحدات تحكم إضافية
    create_additional_controllers
}

create_additional_controllers() {
    # وحدة تحكم العقود
    cat > controllers/contract.controller.js <<EOL
const { Contract, Property, User, Payment } = require('../models');
const { validationResult } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// إنشاء عقد جديد
exports.createContract = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const contractData = req.body;
        contractData.agent_id = req.user.user_id;

        // التحقق من وجود العقار
        const property = await Property.findByPk(contractData.property_id);
        if (!property) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'العقار غير موجود'
            });
        }

        // التحقق من وجود العميل
        const client = await User.findByPk(contractData.client_id);
        if (!client || client.role !== 'client') {
            return res.status(StatusCodes.BAD_REQUEST).json({
                success: false,
                message: 'العميل غير صالح'
            });
        }

        const contract = await Contract.create(contractData);

        logger.info('Contract created successfully', { 
            contractId: contract.contract_id,
            agentId: req.user.user_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: contract,
            message: 'تم إنشاء العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error creating contract', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء إنشاء العقد'
        });
    }
};

// الحصول على عقد بواسطة ID
exports.getContractById = async (req, res) => {
    try {
        const contract = await Contract.findByPk(req.params.id, {
            include: [
                {
                    model: Property,
                    as: 'property',
                    include: ['location']
                },
                {
                    model: User,
                    as: 'client',
                    attributes: ['user_id', 'username', 'email', 'phone']
                },
                {
                    model: User,
                    as: 'agent',
                    attributes: ['user_id', 'username', 'email', 'phone']
                },
                {
                    model: Payment,
                    as: 'payments'
                }
            ]
        });

        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (العميل أو الوكيل أو المدير)
        if (
            req.user.role !== 'admin' &&
            req.user.user_id !== contract.client_id &&
            req.user.user_id !== contract.agent_id
        ) {
            logger.warn('Unauthorized contract access attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بالوصول إلى هذا العقد' 
            });
        }

        logger.info('Contract fetched successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            data: contract
        });
    } catch (error) {
        logger.error('Error getting contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء جلب العقد'
        });
    }
};

// تحديث عقد موجود
exports.updateContract = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const contract = await Contract.findByPk(req.params.id);
        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (الوكيل أو المدير)
        if (req.user.role !== 'admin' && req.user.user_id !== contract.agent_id) {
            logger.warn('Unauthorized contract update attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتعديل هذا العقد' 
            });
        }

        await contract.update(req.body);

        logger.info('Contract updated successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            data: contract,
            message: 'تم تحديث العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error updating contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث العقد'
        });
    }
};

// حذف عقد (soft delete)
exports.deleteContract = async (req, res) => {
    try {
        const contract = await Contract.findByPk(req.params.id);
        if (!contract || contract.deleted_at) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'العقد غير موجود' 
            });
        }

        // التحقق من الصلاحيات (الوكيل أو المدير)
        if (req.user.role !== 'admin' && req.user.user_id !== contract.agent_id) {
            logger.warn('Unauthorized contract deletion attempt', { 
                userId: req.user.user_id,
                contractId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بحذف هذا العقد' 
            });
        }

        await contract.destroy();

        logger.info('Contract deleted successfully', { contractId: contract.contract_id });

        res.json({
            success: true,
            message: 'تم حذف العقد بنجاح'
        });
    } catch (error) {
        logger.error('Error deleting contract', { 
            contractId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء حذف العقد'
        });
    }
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تحكم العقود${NC}"

    # وحدة تحكم المدفوعات
    cat > controllers/payment.controller.js <<EOL
const { Payment, Contract } = require('../models');
const { validationResult } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

// تسجيل دفعة جديدة
exports.createPayment = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const paymentData = req.body;
        paymentData.recorded_by = req.user.user_id;

        // التحقق من وجود العقد
        const contract = await Contract.findByPk(paymentData.contract_id);
        if (!contract) {
            return res.status(StatusCodes.NOT_FOUND).json({
                success: false,
                message: 'العقد غير موجود'
            });
        }

        // التحقق من الصلاحيات (العميل أو الوكيل أو المدير)
        if (
            req.user.role !== 'admin' &&
            req.user.user_id !== contract.client_id &&
            req.user.user_id !== contract.agent_id
        ) {
            logger.warn('Unauthorized payment creation attempt', { 
                userId: req.user.user_id,
                contractId: paymentData.contract_id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتسجيل دفعة لهذا العقد' 
            });
        }

        const payment = await Payment.create(paymentData);

        logger.info('Payment recorded successfully', { 
            paymentId: payment.payment_id,
            contractId: payment.contract_id 
        });

        res.status(StatusCodes.CREATED).json({
            success: true,
            data: payment,
            message: 'تم تسجيل الدفعة بنجاح'
        });
    } catch (error) {
        logger.error('Error recording payment', { 
            error: error.message,
            stack: error.stack 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تسجيل الدفعة'
        });
    }
};

// تحديث حالة الدفعة
exports.updatePaymentStatus = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(StatusCodes.BAD_REQUEST).json({ 
            success: false,
            errors: errors.array() 
        });
    }

    try {
        const payment = await Payment.findByPk(req.params.id);
        if (!payment) {
            return res.status(StatusCodes.NOT_FOUND).json({ 
                success: false,
                message: 'الدفعة غير موجودة' 
            });
        }

        // التحقق من الصلاحيات (المدير فقط)
        if (req.user.role !== 'admin') {
            logger.warn('Unauthorized payment update attempt', { 
                userId: req.user.user_id,
                paymentId: req.params.id 
            });
            return res.status(StatusCodes.FORBIDDEN).json({ 
                success: false,
                message: 'غير مسموح بتحديث حالة الدفعة' 
            });
        }

        await payment.update({ status: req.body.status });

        logger.info('Payment status updated successfully', { 
            paymentId: payment.payment_id,
            newStatus: req.body.status 
        });

        res.json({
            success: true,
            data: payment,
            message: 'تم تحديث حالة الدفعة بنجاح'
        });
    } catch (error) {
        logger.error('Error updating payment status', { 
            paymentId: req.params.id,
            error: error.message 
        });
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
            success: false,
            message: 'حدث خطأ أثناء تحديث حالة الدفعة'
        });
    }
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وحدة تحكم المدفوعات${NC}"
}

# ------ إنشاء المسارات ------
create_routes() {
    echo -e "${YELLOW}🛣️  جاري إنشاء مسارات API...${NC}"
    
    # 1. مسارات المستخدمين
    cat > routes/user.route.js <<EOL
const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');
const upload = require('../utils/fileUpload').upload;

// مسارات عامة
router.post(
  '/register',
  [    check('username')
      .trim()
      .isLength({ min: 3, max: 50 })
      .withMessage('اسم المستخدم يجب أن يكون بين 3 و50 حرفًا')
      .matches(/^[a-zA-Z0-9_]+$/)
      .withMessage('اسم المستخدم يمكن أن يحتوي فقط على أحرف وأرقام وشرطة سفلية'),
    check('email')
      .isEmail()
      .withMessage('البريد الإلكتروني غير صالح')
      .normalizeEmail(),
    check('password')
      .isLength({ min: 8, max: 128 })
      .withMessage('كلمة المرور يجب أن تكون بين 8 و128 حرفًا'),
    check('phone')
      .optional()
      .matches(/^[0-9+]{8,20}$/)
      .withMessage('رقم الهاتف غير صالح'),
    check('role')
      .optional()
      .isIn(['client', 'agent'])
      .withMessage('الدور غير صالح')
  ],
  userController.register
);

router.post(
  '/login',
  [
    check('email')
      .isEmail()
      .withMessage('البريد الإلكتروني غير صالح')
      .normalizeEmail(),
    check('password')
      .notEmpty()
      .withMessage('كلمة المرور مطلوبة')
  ],
  userController.login
);

// مسارات محمية بالمصادقة
router.use(authenticate);

router.get('/me', userController.getMe);

router.put(
  '/:userId',
  [
    check('username')
      .optional()
      .trim()
      .isLength({ min: 3, max: 50 }),
    check('phone')
      .optional()
      .matches(/^[0-9+]{8,20}$/),
    check('profile_image')
      .optional()
      .isURL()
  ],
  userController.updateUser
);

router.delete('/:userId', userController.deleteUser);

// مسارات المدير فقط
router.use(checkRole(['admin']));

router.get('/', userController.getAllUsers);

router.patch('/:userId/status', [
  check('is_active').isBoolean()
], userController.updateUserStatus);

module.exports = router;
EOL
    echo -e "${GREEN}✔ تم إنشاء مسارات المستخدمين${NC}"

    # 2. مسارات العقارات
    cat > routes/property.route.js <<EOL
const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/property.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');
const upload = require('../utils/fileUpload').upload;

// مسارات عامة
router.get('/', propertyController.getAllProperties);
router.get('/:id', propertyController.getPropertyById);

// مسارات محمية
router.use(authenticate);

// إنشاء عقار (للوكلاء والمديرين)
router.post(
  '/',
  checkRole(['admin', 'agent']),
  upload.array('images', 10),
  [
    check('title')
      .trim()
      .isLength({ min: 5, max: 200 })
      .withMessage('العنوان يجب أن يكون بين 5 و200 حرف'),
    check('description')
      .optional()
      .isLength({ max: 5000 }),
    check('price')
      .isDecimal()
      .withMessage('يجب أن يكون السعر رقم عشري')
      .toFloat(),
    check('type')
      .isIn(['sale', 'rent'])
      .withMessage('النوع يجب أن يكون بيع أو إيجار'),
    check('bedrooms')
      .optional()
      .isInt({ min: 0 })
      .toInt(),
    check('bathrooms')
      .optional()
      .isInt({ min: 0 })
      .toInt(),
    check('area')
      .optional()
      .isDecimal()
      .toFloat(),
    check('location_id')
      .isUUID()
      .withMessage('معرف الموقع غير صالح'),
    check('features')
      .optional()
      .isArray()
  ],
  propertyController.createProperty
);

// تحديث عقار (للمالك أو المدير)
router.put(
  '/:id',
  [
    check('title')
      .optional()
      .trim()
      .isLength({ min: 5, max: 200 }),
    check('description')
      .optional()
      .isLength({ max: 5000 }),
    check('price')
      .optional()
      .isDecimal()
      .toFloat(),
    check('status')
      .optional()
      .isIn(['available', 'sold', 'rented', 'pending']),
    check('features')
      .optional()
      .isArray()
  ],
  propertyController.updateProperty
);

// حذف عقار (للمالك أو المدير)
router.delete('/:id', propertyController.deleteProperty);

// إدارة صور العقار
router.post('/:id/images', upload.array('images', 10), propertyController.addImages);
router.patch('/:id/images/:imageId/primary', propertyController.setPrimaryImage);
router.delete('/:id/images/:imageId', propertyController.deleteImage);

module.exports = router;
EOL
    echo -e "${GREEN}✔ تم إنشاء مسارات العقارات${NC}"

    # 3. مسارات العقود
    cat > routes/contract.route.js <<EOL
const express = require('express');
const router = express.Router();
const contractController = require('../controllers/contract.controller');
const { check } = require('express-validator');
const authenticate = require('../middlewares/auth.middleware');
const checkRole = require('../middlewares/roles.middleware');

// مسارات محمية
router.use(authenticate);

// إنشاء عقد (للوكلاء والمديرين)
router.post(
  '/',
  checkRole(['admin', 'agent']),
  [
    check('property_id')
      .isUUID()
      .withMessage('معرف العقار غير صالح'),
    check('client_id')
      .isUUID()
      .withMessage('معرف العميل غير صالح'),
    check('start_date')
      .isDate()
      .withMessage('تاريخ البداية غير صالح'),
    check('end_date')
      .optional()
      .isDate(),
    check('contract_type')
      .isIn(['sale', 'rent'])
      .withMessage('نوع العقد غير صالح'),
    check('amount')
      .isDecimal()
      .withMessage('يجب أن يكون المبلغ رقم عشري')
      .toFloat(),
    check('commission_rate')
      .optional()
      .isDecimal()
      .toFloat()
  ],
  contractController.createContract
);

// الحصول على عقد
router.get('/:id', contractController.getContractById);

// تحديث عقد (للوكيل أو المدير)
router.put(
  '/:id',
  checkRole(['admin', 'agent']),
  [
    check('status')
      .optional()
      .isIn(['active', 'completed', 'terminated', 'pending']),
    check('completion_date')
      .optional()
      .isDate()
  ],
  contractController.updateContract
);

// حذف عقد (للوكيل أو المدير)
router.delete('/:id', checkRole(['admin', 'agent']), contractController.deleteContract);

module.exports = router;
EOL
    echo -e "${GREEN}✔ تم إنشاء مسارات العقود${NC}"

    # 4. المسارات الرئيسية
    cat > routes/index.js <<EOL
const express = require('express');
const router = express.Router();
const userRouter = require('./user.route');
const propertyRouter = require('./property.route');
const contractRouter = require('./contract.route');
const { metricsMiddleware } = require('../utils/monitoring');
const setupSwagger = require('../utils/swagger');

// مراقبة الأداء
router.use(metricsMiddleware);

// نقاط النهاية
router.use('/users', userRouter);
router.use('/properties', propertyRouter);
router.use('/contracts', contractRouter);

// نقطة فحص الصحة
router.get('/health', (req, res) => {
  res.json({ 
    status: 'UP',
    timestamp: new Date().toISOString()
  });
});

// توثيق API
setupSwagger(router);

module.exports = router;
EOL
    echo -e "${GREEN}✔ تم إنشاء المسارات الرئيسية${NC}"
}

# ------ إنشاء الوسائط ------
create_middlewares() {
    echo -e "${YELLOW}🛡️  جاري إنشاء وسائط الأمان...${NC}"
    
    # 1. وسيط المصادقة
    cat > middlewares/auth.middleware.js <<EOL
const jwt = require('jsonwebtoken');
const { TokenExpiredError } = require('jsonwebtoken');
const { User } = require('../models');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

module.exports = async (req, res, next) => {
  try {
    // 1. التحقق من وجود token في الرأس
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      logger.warn('Attempt to access protected route without token');
      return res.status(StatusCodes.UNAUTHORIZED).json({
        success: false,
        message: 'الرجاء تسجيل الدخول للوصول إلى هذا المورد'
      });
    }

    // 2. التحقق من صحة token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err instanceof TokenExpiredError) {
        logger.warn('Expired token attempt');
        return res.status(StatusCodes.UNAUTHORIZED).json({
          success: false,
          message: 'انتهت صلاحية جلسة العمل، الرجاء تسجيل الدخول مرة أخرى'
        });
      }
      throw err;
    }

    // 3. التحقق من وجود المستخدم
    const currentUser = await User.findByPk(decoded.userId);
    if (!currentUser || currentUser.deleted_at) {
      logger.warn('Invalid token - user not found');
      return res.status(StatusCodes.UNAUTHORIZED).json({
        success: false,
        message: 'المستخدم الذي ينتمي إليه هذا الرمز لم يعد موجودًا'
      });
    }

    // 4. التحقق من أن المستخدم نشط
    if (!currentUser.is_active) {
      logger.warn('Inactive user attempt', { userId: decoded.userId });
      return res.status(StatusCodes.FORBIDDEN).json({
        success: false,
        message: 'حساب المستخدم غير مفعل، الرجاء التواصل مع الدعم الفني'
      });
    }

    // 5. إضافة المستخدم إلى الطلب
    req.user = {
      user_id: currentUser.user_id,
      username: currentUser.username,
      email: currentUser.email,
      role: currentUser.role,
      profile_image: currentUser.profile_image
    };

    logger.info('User authenticated', { userId: currentUser.user_id });
    next();
  } catch (error) {
    logger.error('Authentication error', { 
      error: error.message,
      stack: error.stack 
    });
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: 'حدث خطأ أثناء المصادقة'
    });
  }
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وسيط المصادقة${NC}"

    # 2. وسيط الصلاحيات
    cat > middlewares/roles.middleware.js <<EOL
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

const checkRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      logger.warn('Unauthorized role attempt', { 
        userRole: req.user?.role, 
        allowedRoles 
      });
      return res.status(StatusCodes.FORBIDDEN).json({ 
        success: false,
        message: 'غير مسموح بالوصول إلى هذا المورد' 
      });
    }
    next();
  };
};

const checkOwnership = (model) => {
  return async (req, res, next) => {
    try {
      const record = await model.findByPk(req.params.id);
      
      if (!record) {
        return res.status(StatusCodes.NOT_FOUND).json({ 
          success: false,
          message: 'السجل غير موجود' 
        });
      }

      // السماح للمديرين دائماً
      if (req.user.role === 'admin') {
        return next();
      }

      // التحقق من ملكية السجل
      if (record.user_id !== req.user.user_id) {
        logger.warn('Unauthorized ownership attempt', { 
          userId: req.user.user_id,
          recordId: req.params.id 
        });
        return res.status(StatusCodes.FORBIDDEN).json({ 
          success: false,
          message: 'غير مسموح بالتعديل على هذا السجل' 
        });
      }

      next();
    } catch (error) {
      logger.error('Ownership check error', { 
        error: error.message,
        stack: error.stack 
      });
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({ 
        success: false,
        message: 'حدث خطأ أثناء التحقق من الملكية' 
      });
    }
  };
};

module.exports = {
  checkRole,
  checkOwnership
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وسيط الصلاحيات${NC}"

    # 3. وسيط معالجة الأخطاء
    cat > middlewares/error.middleware.js <<EOL
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');

module.exports = (err, req, res, next) => {
  logger.error('Unhandled error', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method
  });

  const statusCode = err.statusCode || StatusCodes.INTERNAL_SERVER_ERROR;
  const message = process.env.NODE_ENV === 'production'
    ? 'حدث خطأ في الخادم'
    : err.message;

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  });
};
EOL
    echo -e "${GREEN}✔ تم إنشاء وسيط معالجة الأخطاء${NC}"
}

# ------ التنفيذ الرئيسي ------
main() {
    echo -e "${GREEN}
    ╔══════════════════════════════╗
    ║   Real Estate API Setup      ║
    ║   الجزء الثالث - المسارات  ║
    ╚══════════════════════════════╝
    ${NC}"

    # 1. التحقق من البيئة
    check_environment
    
    # 2. إنشاء وحدات التحكم
    create_controllers
    
    # 3. إنشاء المسارات
    create_routes
    
    # 4. إنشاء الوسائط
    create_middlewares
    
    echo -e "${GREEN}
    ✅ تم إعداد الجزء الثالث بنجاح!
    → الميزات المضمنة:
    - نظام مستخدمين كامل (تسجيل، دخول، صلاحيات)
    - إدارة عقارات متقدمة (تصفية، ترتيب، صور)
    - نظام عقود متكامل
    - وسائط أمان متقدمة
    - توثيق API تلقائي
    ${NC}"
}

# ------ بدء التنفيذ ------
main