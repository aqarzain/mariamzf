#!/bin/bash

# سكربت الجزء الثاني: نماذج قاعدة البيانات المحدثة
# إصدار 2.5 - متوافق مع Termux وأنظمة Linux/macOS
# يشمل تحسينات العلاقات، الفهارس، والتحقق من صحة البيانات

# ------ إعدادات أولية ------
set -e  # إيقاف السكربت عند أول خطأ

# ألوان للواجهة
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ------ التحقق من البيئة ------
check_environment() {
    echo -e "${YELLOW}🔍 التحقق من بيئة التنفيذ...${NC}"
    
    if [ ! -f "package.json" ]; then
        echo -e "${RED}❌ يجب تنفيذ الجزء الأول أولاً (setup.sh)${NC}"
        exit 1
    fi
    
    if [[ $(uname -o) == *"Android"* ]]; then
        echo -e "${YELLOW}📱 تم الكشف عن Termux، تطبيق إعدادات خاصة...${NC}"
        TERMUX_ENV=true
    else
        echo -e "${YELLOW}🖥️  تم الكشف عن نظام عادي (Linux/macOS)${NC}"
        TERMUX_ENV=false
    fi
    
    echo -e "${GREEN}✅ البيئة جاهزة${NC}"
}

# ------ إنشاء النماذج ------
create_models() {
    echo -e "${YELLOW}⚙️  جاري إنشاء نماذج قاعدة البيانات...${NC}"
    
    # 1. نموذج المستخدم (User)
    cat > models/user.model.js <<EOL
const { DataTypes } = require('sequelize');
const bcrypt = require('bcryptjs');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    user_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    username: {
      type: DataTypes.STRING(50),
      allowNull: false,
      unique: true,
      validate: {
        notEmpty: true,
        len: [3, 50],
        is: /^[a-zA-Z0-9_]+$/i
      }
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
      validate: {
        notEmpty: true,
        isEmail: true,
        len: [5, 100]
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [8, 128]
      }
    },
    phone: {
      type: DataTypes.STRING(20),
      validate: {
        is: /^[0-9+]{8,20}$/
      }
    },
    role: {
      type: DataTypes.ENUM('admin', 'agent', 'client'),
      defaultValue: 'client',
      allowNull: false
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    last_login: {
      type: DataTypes.DATE
    },
    profile_image: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['email'], unique: true },
      { fields: ['username'], unique: true },
      { fields: ['role'] }
    ],
    hooks: {
      beforeSave: async (user) => {
        if (user.changed('password')) {
          user.password = await bcrypt.hash(user.password, 12);
        }
      }
    }
  });

  User.prototype.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
  };

  User.associate = function(models) {
    User.hasMany(models.Property, { foreignKey: 'user_id', as: 'properties' });
    User.hasMany(models.Contract, { foreignKey: 'client_id', as: 'client_contracts' });
    User.hasMany(models.Contract, { foreignKey: 'agent_id', as: 'agent_contracts' });
    User.hasMany(models.Document, { foreignKey: 'user_id', as: 'documents' });
  };

  return User;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج المستخدم${NC}"

    # 2. نموذج الموقع (Location)
    cat > models/location.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Location = sequelize.define('Location', {
    location_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    city: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 100]
      }
    },
    neighborhood: {
      type: DataTypes.STRING(100),
      validate: {
        len: [0, 100]
      }
    },
    latitude: {
      type: DataTypes.DECIMAL(10, 7),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: -90,
        max: 90
      }
    },
    longitude: {
      type: DataTypes.DECIMAL(10, 7),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: -180,
        max: 180
      }
    },
    zip_code: {
      type: DataTypes.STRING(20),
      validate: {
        len: [0, 20]
      }
    },
    address: {
      type: DataTypes.STRING(255),
      validate: {
        len: [0, 255]
      }
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['city'] },
      { fields: ['neighborhood'] },
      { fields: ['latitude', 'longitude'], using: 'BTREE' }
    ]
  });

  Location.associate = function(models) {
    Location.hasMany(models.Property, { foreignKey: 'location_id', as: 'properties' });
  };

  return Location;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج الموقع${NC}"

    # 3. نموذج العقار (Property)
    cat > models/property.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Property = sequelize.define('Property', {
    property_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(200),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [5, 200]
      }
    },
    description: {
      type: DataTypes.TEXT,
      validate: {
        len: [0, 5000]
      }
    },
    price: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    type: {
      type: DataTypes.ENUM('sale', 'rent'),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('available', 'sold', 'rented', 'pending'),
      defaultValue: 'available'
    },
    bedrooms: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 0
      }
    },
    bathrooms: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 0
      }
    },
    area: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    year_built: {
      type: DataTypes.INTEGER,
      validate: {
        isInt: true,
        min: 1800,
        max: new Date().getFullYear()
      }
    },
    is_featured: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    video_url: {
      type: DataTypes.STRING,
      validate: {
        isUrl: true
      }
    },
    floor_plan: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['price'] },
      { fields: ['type', 'status'] },
      { fields: ['location_id'] },
      { fields: ['user_id'] },
      { fields: ['is_featured'] },
      { type: 'FULLTEXT', fields: ['title', 'description'] }
    ]
  });

  Property.associate = function(models) {
    Property.belongsTo(models.User, { foreignKey: 'user_id', as: 'owner' });
    Property.belongsTo(models.Location, { foreignKey: 'location_id', as: 'location' });
    Property.belongsToMany(models.Feature, {
      through: 'PropertyFeatures',
      foreignKey: 'property_id',
      as: 'features'
    });
    Property.hasMany(models.PropertyImage, { foreignKey: 'property_id', as: 'images' });
    Property.hasMany(models.Contract, { foreignKey: 'property_id', as: 'contracts' });
    Property.hasMany(models.PropertyReview, { foreignKey: 'property_id', as: 'reviews' });
  };

  return Property;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج العقار${NC}"

    # 4. نموذج العقد (Contract)
    cat > models/contract.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Contract = sequelize.define('Contract', {
    contract_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    start_date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    end_date: {
      type: DataTypes.DATEONLY
    },
    contract_type: {
      type: DataTypes.ENUM('sale', 'rent'),
      allowNull: false
    },
    amount: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    commission_rate: {
      type: DataTypes.DECIMAL(5, 2),
      validate: {
        isDecimal: true,
        min: 0,
        max: 100
      }
    },
    completion_date: {
      type: DataTypes.DATEONLY
    },
    terms: {
      type: DataTypes.TEXT
    },
    status: {
      type: DataTypes.ENUM('active', 'completed', 'terminated', 'pending'),
      defaultValue: 'pending'
    },
    payment_terms: {
      type: DataTypes.TEXT
    },
    notes: {
      type: DataTypes.TEXT
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['client_id'] },
      { fields: ['property_id'] },
      { fields: ['agent_id'] },
      { fields: ['start_date', 'end_date'] },
      { fields: ['status'] }
    ]
  });

  Contract.associate = function(models) {
    Contract.belongsTo(models.User, { foreignKey: 'client_id', as: 'client' });
    Contract.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
    Contract.belongsTo(models.User, { foreignKey: 'agent_id', as: 'agent' });
    Contract.hasMany(models.Payment, { foreignKey: 'contract_id', as: 'payments' });
    Contract.hasMany(models.Document, { foreignKey: 'contract_id', as: 'documents' });
  };

  return Contract;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج العقد${NC}"

    # 5. نماذج إضافية
    create_additional_models
}

create_additional_models() {
    # نموذج الدفع (Payment)
    cat > models/payment.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Payment = sequelize.define('Payment', {
    payment_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    amount: {
      type: DataTypes.DECIMAL(15, 2),
      allowNull: false,
      validate: {
        isDecimal: true,
        min: 0
      }
    },
    payment_method: {
      type: DataTypes.ENUM(
        'cash', 
        'bank_transfer', 
        'credit_card', 
        'vodafone_cash', 
        'paypal',
        'other'
      ),
      allowNull: false
    },
    transaction_id: {
      type: DataTypes.STRING(100),
      unique: true
    },
    receipt_number: {
      type: DataTypes.STRING(50)
    },
    payment_date: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    },
    notes: {
      type: DataTypes.TEXT
    },
    is_commission_paid: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    status: {
      type: DataTypes.ENUM('pending', 'completed', 'failed', 'refunded'),
      defaultValue: 'pending'
    },
    payment_proof: {
      type: DataTypes.STRING
    }
  }, {
    timestamps: true,
    paranoid: true,
    indexes: [
      { fields: ['contract_id'] },
      { fields: ['payment_date'] },
      { fields: ['transaction_id'], unique: true },
      { fields: ['status'] }
    ]
  });

  Payment.associate = function(models) {
    Payment.belongsTo(models.Contract, { foreignKey: 'contract_id', as: 'contract' });
    Payment.belongsTo(models.User, { foreignKey: 'recorded_by', as: 'recorder' });
  };

  return Payment;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج الدفع${NC}"

    # نموذج تقييم العقار (PropertyReview)
    cat > models/propertyReview.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyReview = sequelize.define('PropertyReview', {
    review_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    rating: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1,
        max: 5
      }
    },
    comment: {
      type: DataTypes.TEXT,
      validate: {
        len: [0, 1000]
      }
    },
    is_approved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['property_id'] },
      { fields: ['user_id'] },
      { fields: ['rating'] },
      { fields: ['is_approved'] }
    ]
  });

  PropertyReview.associate = function(models) {
    PropertyReview.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
    PropertyReview.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
  };

  return PropertyReview;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج تقييم العقار${NC}"

    # نموذج الميزات (Feature)
    cat > models/feature.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Feature = sequelize.define('Feature', {
    feature_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(50),
      unique: true,
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 50]
      }
    },
    icon: {
      type: DataTypes.STRING(50)
    },
    category: {
      type: DataTypes.ENUM('internal', 'external', 'amenity', 'safety'),
      defaultValue: 'amenity'
    },
    is_filterable: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['name'], unique: true },
      { fields: ['category'] },
      { fields: ['is_filterable'] }
    ]
  });

  Feature.associate = function(models) {
    Feature.belongsToMany(models.Property, {
      through: 'PropertyFeatures',
      foreignKey: 'feature_id',
      as: 'properties'
    });
  };

  return Feature;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج الميزات${NC}"

    # نموذج صور العقار (PropertyImage)
    cat > models/propertyImage.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyImage = sequelize.define('PropertyImage', {
    image_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    image_url: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        isUrl: true
      }
    },
    is_primary: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    caption: {
      type: DataTypes.STRING(100),
      validate: {
        len: [0, 100]
      }
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['property_id'] },
      { fields: ['is_primary'] }
    ]
  });

  PropertyImage.associate = function(models) {
    PropertyImage.belongsTo(models.Property, { foreignKey: 'property_id', as: 'property' });
  };

  return PropertyImage;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج صور العقار${NC}"

    # نموذج الوثائق (Document)
    cat > models/document.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Document = sequelize.define('Document', {
    document_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: true,
        len: [2, 100]
      }
    },
    file_url: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        isUrl: true
      }
    },
    document_type: {
      type: DataTypes.ENUM(
        'contract', 
        'id_proof', 
        'property_deed', 
        'payment_receipt',
        'other'
      ),
      allowNull: false
    },
    notes: {
      type: DataTypes.TEXT
    }
  }, {
    timestamps: true,
    paranoid: false,
    indexes: [
      { fields: ['contract_id'] },
      { fields: ['user_id'] },
      { fields: ['document_type'] }
    ]
  });

  Document.associate = function(models) {
    Document.belongsTo(models.Contract, { foreignKey: 'contract_id', as: 'contract' });
    Document.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
  };

  return Document;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج الوثائق${NC}"

    # نموذج PropertyFeature (جدول الربط)
    cat > models/propertyFeature.model.js <<EOL
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const PropertyFeature = sequelize.define('PropertyFeature', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    custom_value: {
      type: DataTypes.STRING(50),
      allowNull: true
    }
  }, {
    timestamps: false,
    tableName: 'PropertyFeatures'
  });

  return PropertyFeature;
};
EOL
    echo -e "${GREEN}✔ تم إنشاء نموذج علاقات الميزات${NC}"
}

# ------ تهيئة النماذج الرئيسية ------
init_models_index() {
    echo -e "${YELLOW}⚙️  جاري تهيئة ملف models/index.js...${NC}"
    
    cat > models/index.js <<EOL
const { Sequelize } = require('sequelize');
const config = require('../config/database');
const logger = require('../utils/logger');

// تهيئة Sequelize مع إعدادات خاصة لـ Termux
const sequelize = new Sequelize({
  dialect: config[process.env.NODE_ENV].dialect,
  storage: config[process.env.NODE_ENV].storage,
  logging: msg => logger.debug(msg),
  define: {
    ...config[process.env.NODE_ENV].define,
    // إصلاح مشكلة الجداول في SQLite
    $( [[ $TERMUX_ENV == "true" ]] && echo "freezeTableName: true," )
  }
});

// استيراد النماذج
const User = require('./user.model')(sequelize);
const Property = require('./property.model')(sequelize);
const Location = require('./location.model')(sequelize);
const Feature = require('./feature.model')(sequelize);
const PropertyFeature = require('./propertyFeature.model')(sequelize);
const Contract = require('./contract.model')(sequelize);
const Payment = require('./payment.model')(sequelize);
const Document = require('./document.model')(sequelize);
const PropertyReview = require('./propertyReview.model')(sequelize);
const PropertyImage = require('./propertyImage.model')(sequelize);

// تعريف العلاقات
User.hasMany(Property, { foreignKey: 'user_id', as: 'properties' });
Property.belongsTo(User, { foreignKey: 'user_id', as: 'owner' });

Location.hasMany(Property, { foreignKey: 'location_id', as: 'properties' });
Property.belongsTo(Location, { foreignKey: 'location_id', as: 'location' });

Property.belongsToMany(Feature, {
  through: PropertyFeature,
  foreignKey: 'property_id',
  as: 'features'
});
Feature.belongsToMany(Property, {
  through: PropertyFeature,
  foreignKey: 'feature_id',
  as: 'properties'
});

Property.hasMany(PropertyImage, { foreignKey: 'property_id', as: 'images' });
PropertyImage.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

Property.hasMany(Contract, { foreignKey: 'property_id', as: 'contracts' });
Contract.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

User.hasMany(Contract, { foreignKey: 'client_id', as: 'client_contracts' });
Contract.belongsTo(User, { foreignKey: 'client_id', as: 'client' });

User.hasMany(Contract, { foreignKey: 'agent_id', as: 'agent_contracts' });
Contract.belongsTo(User, { foreignKey: 'agent_id', as: 'agent' });

Contract.hasMany(Payment, { foreignKey: 'contract_id', as: 'payments' });
Payment.belongsTo(Contract, { foreignKey: 'contract_id', as: 'contract' });

User.hasMany(Payment, { foreignKey: 'recorded_by', as: 'recorded_payments' });
Payment.belongsTo(User, { foreignKey: 'recorded_by', as: 'recorder' });

Contract.hasMany(Document, { foreignKey: 'contract_id', as: 'documents' });
Document.belongsTo(Contract, { foreignKey: 'contract_id', as: 'contract' });

User.hasMany(Document, { foreignKey: 'user_id', as: 'documents' });
Document.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Property.hasMany(PropertyReview, { foreignKey: 'property_id', as: 'reviews' });
PropertyReview.belongsTo(Property, { foreignKey: 'property_id', as: 'property' });

User.hasMany(PropertyReview, { foreignKey: 'user_id', as: 'reviews' });
PropertyReview.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// مزامنة النماذج مع قاعدة البيانات
const syncModels = async () => {
  try {
    if (process.env.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      logger.info('تم مزامنة النماذج مع قاعدة البيانات');
    } else {
      await sequelize.sync();
    }
  } catch (error) {
    logger.error('فشل مزامنة النماذج:', error);
    process.exit(1);
  }
};

module.exports = {
  sequelize,
  syncModels,
  User,
  Property,
  Location,
  Feature,
  PropertyFeature,
  Contract,
  Payment,
  Document,
  PropertyReview,
  PropertyImage
};
EOL
    echo -e "${GREEN}✔ تم تهيئة ملف النماذج الرئيسي${NC}"
}

# ------ التنفيذ الرئيسي ------
main() {
    echo -e "${GREEN}
    ╔══════════════════════════════╗
    ║   Real Estate Models Setup   ║
    ║   الجزء الثاني - النماذج    ║
    ╚══════════════════════════════╝
    ${NC}"

    # 1. التحقق من البيئة
    check_environment
    
    # 2. إنشاء نماذج قاعدة البيانات
    create_models
    
    # 3. تهيئة ملف النماذج الرئيسي
    init_models_index
    
    echo -e "${GREEN}
    ✅ تم إنشاء نماذج قاعدة البيانات بنجاح!
    → يمكنك الآن تنفيذ الجزء الثالث
    ${NC}"
}

# ------ بدء التنفيذ ------
main